# TEST VARIABLE
row_tile = 15
col_tile = 28
screen_reapeat = 4

import pygame, sys, platform, csv
import math
from os import walk
import os
from pygame.locals import *

pygame.init()

#! === window ===
original_screen_width = 1200
original_screen_hight = 700

screen = pygame.display.set_mode((original_screen_width, original_screen_hight)) #pygame.FULLSCREEN
pygame.display.set_caption("GAME")

# === Variable ===
clock = pygame.time.Clock()
fps = 60
run = True
click = False
scrool = 0
tile_size = 46.666
level_num = 1
dead = False
finnish_state = False

def os_find():
    global script_path, current_os, slash
    script_path = os.path.dirname(os.path.abspath(__file__))
    current_os = platform.system()
    if current_os == "Darwin":
        slash="/"
        script_path = script_path.replace("/editor","")
    else:
        slash="\\"
        script_path = script_path[:0] + "C" + script_path[1:]
        script_path = script_path.replace("\editor","")

#! === = Loops = === #
#? === Main Loop === #
def main_menu_loop():
    global new_pos_x, new_pos_y, fps, run, button_list, exit_btn,finnish_state
    scale_pos()
    load_button()
    main_menu = MainMenu()

    while run:
        scale_pos()
        screen.blit(button_list[20], (0/new_pos_x,0/new_pos_y))
       
        # --- run ---
        main_menu.run()
        # - Exit -
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                sys.exit()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
                pygame.quit()
                sys.exit()
        
        # --- Buttons ---
        if exit_btn.draw_button(screen):
            pygame.quit()
            sys.exit()
        if new_game_btn.draw_button(screen):
            player_name_input()
        if load_save_btn.draw_button(screen):
            save_choose()

        if finnish_state == True:
            finnish_state = False

        clock.tick(fps)
        pygame.display.update()

#? ==== Player Name Imput === 
def player_name_input():
    global run, new_pos_x,new_pos_y, fps, continue_btn, back_btn, text_input
    font = pygame.font.Font(None, int(60/new_pos_x))
    text_input = ""
    text_input_active = False  
    inactive_color = (0, 0, 0) 
    active_color = (255, 0, 0)
    input_class = PlayerInput()
    while run:
        input_class.run()
        screen.blit(button_list[21], (0/new_pos_x,0/new_pos_y))
        scale_pos()

        for event in pygame.event.get():
            # - Exit -
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                sys.exit()

        # --- input bar ---
            # Check for mouse clicks
            elif event.type == pygame.MOUSEBUTTONDOWN:
                # Get the mouse position
                mouse_x, mouse_y = pygame.mouse.get_pos()

                # Check if the mouse is over the text input bar
                if 531 < mouse_x < 779 and 155 < mouse_y < 207: text_input_active = True
                else: text_input_active = False

            # Check for key presses
            elif event.type == pygame.KEYDOWN and text_input_active:
                if event.key == pygame.K_BACKSPACE:
                    text_input = text_input[:-1]
                elif event.key == pygame.K_RETURN:
                    text_input_active = False
                else:
                    text_input += event.unicode   

        # Draw the text input bar
        if text_input_active: color = active_color
        else: color = inactive_color

        # Check if the text input is longer than the text input bar
        text_width, text_height = font.size(text_input)
        
        # Render the text input
        text = font.render(text_input, True, (255, 255, 255))
        screen.blit(text, (536/new_pos_x, 165/new_pos_y))

        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
                pygame.quit()
                sys.exit() 

        if continue_btn.draw_button(screen) and text_input != "" or None:
            newpath = f"{script_path}/files/GameSave/{text_input}".replace("/", slash) 
            if not os.path.exists(newpath):
                os.makedirs(newpath)
                with open(f"{newpath}/level.txt".replace("/", slash), "w") as file: file.write("1")
            level_choose("input")
        
        if back_btn.draw_button(screen):
            main_menu_loop()

        clock.tick(fps)
        pygame.display.update()


#? === Save Choose === 
def save_choose():
    global run, new_pos_x,new_pos_y, text_input
    save_class = SaveChoose()
    while run:
        screen.blit(button_list[19], (0/new_pos_x,0/new_pos_y))
        save_class.run()
        # - Exit -
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                sys.exit()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
                pygame.quit()
                sys.exit()

        if back_btn.draw_button(screen):
            main_menu_loop()

        button_row = 0
        button_collum = -1
        for button_count,i in enumerate(save_button_list):
                if i.draw_button(screen): 
                    text_input = save_list[button_count]
                    level_choose("save")
                if button_count == 3:
                    button_row += 1
                    button_collum = -1
                elif button_count == 0: button_row = 0
                elif button_count >= 6: button_row = 1000
                button_collum += 1
                text_rect = folder_text[button_count].get_rect(center=((295 + (205 * button_collum)+100)/new_pos_x,(120+(123 * button_row)+50)/new_pos_y))

                screen.blit(folder_text[button_count],text_rect)
                    
        clock.tick(fps)
        pygame.display.update()
        
#? === Level Choose === 
def level_choose(back_status = "save"):
    global run, new_pos_x, new_pos_y, fps, level_num, finnish_state, unlocked_level
    choose_class = LevelChoose(screen)
    while run:
        scale_pos()
        screen.blit(button_list[18], (0/new_pos_x,0/new_pos_y))
        choose_class.run()
        # - Exit -
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                sys.exit()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
                pygame.quit()
                sys.exit()
            
        with open(f"{script_path}/files/GameSave/{text_input}/level.txt".replace("/", slash), "r") as file: unlocked_level = int(file.read())

        # --- Buttons --- #
        if back_btn.draw_button(screen):
            if back_status == "input":
                player_name_input()
            elif back_status == "save":
                save_choose()

        for _ ,i in enumerate(level_button_list):
            if i.draw_button(screen) and level_num <= unlocked_level:
                level_loop()

        
        # -- chnage level -- #
        if left_arrow_level_btn.draw_button(screen) and level_num > 1:
            level_num -= 1
        if right_arrow_level_btn.draw_button(screen) and len(level_button_list) > level_num:
            level_num += 1

        font = pygame.font.Font(None, int(70/new_pos_x))
        text = font.render(str(f"Level {level_num}"), True, (0, 0, 0))
        screen.blit(text, (520/new_pos_x, 285/new_pos_y))

        # -- draw locker -- #
        if level_num > unlocked_level:
            screen.blit(locker_img, (520/new_pos_x, 220/new_pos_y))

        if finnish_state == True: finnish_state = False

        clock.tick(fps)
        pygame.display.update()

# ?=== Death screen === 
def death_loop():
    global run, fps, new_pos_x, new_pos_y, finnish_state, scrool, level_num
    death_class = DeathScreen()
    while run:
        scale_pos()
        screen.blit(button_list[22], (0/new_pos_x,0/new_pos_y))
        death_class.run()
        
        # Exit
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                sys.exit()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
                pygame.quit()
                sys.exit()

        # - Buttons - 
        if retry_btn.draw_button(screen):
            level_loop()
        if back_btn.draw_button(screen):
            level_choose()

        if finnish_state == True: finnish_state = False

        clock.tick(fps)
        pygame.display.update()


#? === Level Screen Loop ===
def level_loop():
    global new_pos_x, new_pos_y, tile_size,fps, run, scrool, dead, finnish_state
    scrool = 0
    dead = False
    import_bg()
    load_level() 
    level = Level(level_map,screen) 
    while run:
        scale_pos()
        #screen.fill("black")
        tile_size = 46.666 
        # --- run ---
        level.run()
        # - Exit -
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                sys.exit()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_ESCAPE]:
                pygame.quit()
                sys.exit()
        
        if finnish_state == True:
            if level_num == unlocked_level:
                 with open(f"{script_path}/files/GameSave/{text_input}/level.txt".replace("/", slash), "w") as file: file.write(str(unlocked_level+1))
            level_choose()
        

        if dead == True: 
            death_loop()

        clock.tick(fps)
        pygame.display.update()


#! === === ALL Classes === === #
#* === Main Menu functions === #
class MainMenu:
    def button_placing(self):
        global new_game_btn, exit_btn, load_save_btn
        new_game_btn = Button(505/new_pos_x,165/new_pos_y, button_list[0], 1,True, button_list[1])
        load_save_btn = Button(505/new_pos_x,269/new_pos_y, button_list[2], 1,True, button_list[3])
        exit_btn = Button(505/new_pos_x,376/new_pos_y, button_list[6], 1,True, button_list[7])

    def run(self):
        self.button_placing()


#* === Player Input Class === 
class PlayerInput:
    def button_placing(self):
        global continue_btn, back_btn
        continue_btn = Button(506/new_pos_x,246/new_pos_y, button_list[8], 1,True, button_list[9])
        back_btn = Button(506/new_pos_x,580/new_pos_y, button_list[4], 1,True, button_list[5])

    def run(self):
        self.button_placing()


#* === Save Choose Class ===
class SaveChoose:
    def __init__(self):
        self.path = f"{script_path}/files/GameSave".replace("/", slash)
        self.folders = [item for item in os.listdir(self.path) if os.path.isdir(os.path.join(self.path, item))]

    def button_placing(self):
        global back_btn, save_button_list,save_list,folder_text
        back_btn = Button(520/new_pos_x,580/new_pos_y, button_list[4], 1,True, button_list[5])
        save_button_list, save_list, folder_text = [], [], []
        self.font = pygame.font.Font(None, 32)
        self.row, self.collum = 0,-1
        for i in range(len(self.folders)):
            if i == 3:
                self.row += 1
                self.collum = -1
            elif i == 0: self.row = 0
            elif i >= 6: self.row = 1000
            self.collum += 1

            btn = Button((295 + (205 * self.collum))/new_pos_x,(120+(123 * self.row))/new_pos_y, button_list[16], 1,True, button_list[17])
            save_list.append(self.folders[i])
            save_button_list.append(btn)
            self.text = self.font.render(self.folders[i],True, "red")
            folder_text.append(self.text)

    def run(self):
        self.button_placing()


#* === Level Choose Class ===
class LevelChoose:
    def __init__(self, surface):
        global level_button_list
        self.display_surface = surface
        level_button_list = self.level_button_list_def()
        self.locker_img()

    def button_placing(self):
        global back_btn, left_arrow_level_btn, right_arrow_level_btn
        back_btn = Button(510/new_pos_x,580/new_pos_y, button_list[4], 1,True, button_list[5])
        left_arrow_level_btn = Button(430/new_pos_x,280/new_pos_y, button_list[12], 1,True, button_list[13])
        right_arrow_level_btn =  Button(720/new_pos_x,280/new_pos_y, button_list[14], 1,True, button_list[15])
    
    def make_list_of_level(self):
        self.level_file = f"{script_path}/files/level".replace("/", slash)
        return [f for f in os.listdir(self.level_file) if os.path.isdir(os.path.join(self.level_file, f))]

    def level_button_list_def(self):
        self.level_button_list = []
        self.level_list = self.make_list_of_level()
        for _ in range(len(self.level_list)):
            self.level_button = Button(500/new_pos_x,259/new_pos_y, button_list[16], 1,True, button_list[17])
            self.level_button_list.append(self.level_button)
        return self.level_button_list

    def locker_img(self):
        global locker_img
        locker_img_scale = pygame.image.load(f"{script_path}/files/image/locker.png".replace("/", slash)).convert_alpha()
        locker_img = pygame.transform.scale(locker_img_scale, ((160/new_pos_x),(160/new_pos_y)))

    def run(self):
        global level_button_list
        level_button_list = self.level_button_list_def()
        self.button_placing()
        

#* === Death Screen Class ===
class DeathScreen:
    def __init__(self):
        self.button_placing()

    def button_placing(self):
        global back_btn,retry_btn
        back_btn = Button(506/new_pos_x,307/new_pos_y, button_list[4], 1,True, button_list[5])
        retry_btn = Button(506/new_pos_x,237/new_pos_y, button_list[10], 1,True, button_list[11])

    def run(self):
        self.button_placing()


#+ === Tile Class ===
class Tile(pygame.sprite.Sprite):
    def __init__(self,pos,size):
         super().__init__()
         self.image = pygame.Surface((size/new_pos_x,size/new_pos_y))
         self.rect = self.image.get_rect(topleft = pos)

    def update(self,x_shift):
        self.rect.x += x_shift

        
class StaticTile(Tile):
    def __init__(self,pos,size,surface):
        super().__init__(pos, size)
        self.image = surface
        
class Coin(pygame.sprite.Sprite):
    def __init__(self,pos,num):
        super().__init__()
        self.frame_index = 0
        self.animation_speed = 0.05
        self.num = num
        self.pos = pos
        self.image_list = import_folder(f"{script_path}/coin/{self.num}".replace("/", slash)) 
        self.image = self.image_list[0]
        self.image = pygame.transform.scale(self.image_list[int(self.frame_index)], ((tile_size/new_pos_x/2),(tile_size/new_pos_y/2)))
        self.rect = self.image.get_rect(topleft = pos)
       
    def animation(self):
        self.pos = self.rect.bottom
        self.image = pygame.transform.scale(self.image_list[int(self.frame_index)], ((tile_size/1.5/new_pos_x),(tile_size/1.5/new_pos_y)))

    def update(self,x_shift):
        self.animation()
        self.frame_index += self.animation_speed
        self.rect.x += x_shift
        if self.frame_index >= len(self.image_list):
            self.frame_index = 0
        Coin.rect = self.rect



#+ === Level Setup ===
class Level:
    def __init__(self,level_data,surface):

        # Level Setup
        self.display_surface = surface
        self.setup_level(level_data)
        self.world_shift = 0
        self.current_x = 0
        self.coin_collected = 0

        # dust
        self.dust_sprite = pygame.sprite.GroupSingle()
        self.player_on_ground = False

        # bullet
        Level.bullet_group = pygame.sprite.Group()
        Level.enemy_bullet_group = pygame.sprite.Group()

    def health_bar(self):
        pygame.draw.rect(screen, (255,0,0), (20/new_pos_x, 20/new_pos_y, 200/new_pos_x, 30/new_pos_y))
        pygame.draw.rect(screen, (0, 255, 0), (20/new_pos_x, 20/new_pos_y, int(Player.health / Player.max_health * 200/new_pos_x), 30/new_pos_y))
    
    def create_bullet(self,direction_bulet):
        return Bullet(self.rect.centerx,self.rect.centery,direction_bulet) 
    
    def create_jump_particles(self,pos):
        if self.player.sprite.facing_right:
            pos -= pygame.math.Vector2(10/new_pos_x,5/new_pos_y)
        else:
            pos +=  pygame.math.Vector2(10/new_pos_x,5/new_pos_y)
        jump_particles_sprite = ParticleEffect(pos,"jump",character)
        self.dust_sprite.add(jump_particles_sprite)

    def get_player_on_ground(self):
        if self.player.sprite.on_ground:
            self.player_on_ground = True
        else:
            self.player_on_ground = False

    def create_landing_dust(self):
        if not self.player_on_ground and self.player.sprite.on_ground and not self.dust_sprite.sprites():
            if self.player.sprite.facing_right:
                offset = pygame.math.Vector2(10/new_pos_x,15/new_pos_y)
            else:
                offset = pygame.math.Vector2(-10/new_pos_x,15/new_pos_y)
            fall_dust_particles = ParticleEffect(self.player.sprite.rect.midbottom - offset, "land",character)
            self.dust_sprite.add(fall_dust_particles)

    def setup_level(self,layout):
        global character
        self.tiles = pygame.sprite.Group()
        self.finnish = pygame.sprite.GroupSingle()
        self.player = pygame.sprite.GroupSingle()
        self.enemy = pygame.sprite.Group()
        self.coin = pygame.sprite.Group()
        self.coin_count = 0
        
        terrain_tile_list = import_terrain_tile()

        for row_index, row in enumerate(layout):
            for col_index, cell in enumerate(row):
                x = col_index * tile_size / new_pos_x
                y = row_index * tile_size / new_pos_y
                
                # tiles
                if 99 >= cell >= 0:
                    tile_surface = terrain_tile_list[cell]
                    tile = StaticTile((x,y),tile_size / new_pos_x, tile_surface)
                    self.tiles.add(tile)
                # finnish 
                if -100 >= cell >= -199:
                    self.finnish_block = Finnish((x,y),cell)
                    self.finnish.add(self.finnish_block)
                # melee player
                if 100 <= cell <= 199:   
                    character = cell
                    player_sprite = Player((x,y),self.display_surface,self.create_jump_particles,"melee",cell)
                    self.player.add(player_sprite)
                # range player
                if 200 <= cell <= 299:   
                    character = cell
                    player_sprite = Player((x,y),self.display_surface,self.create_jump_particles,"range",cell)
                    self.player.add(player_sprite)
                # enemies
                if 300 <= cell <=  399:
                    walking_enemy_sprite = WalkingEnemy(x,y,cell)
                    self.enemy.add(walking_enemy_sprite)
                    Level.enemy = self.enemy
                if 400 <= cell <= 499:
                    shooting_enemy_sprite = ShootingEnemy(x,y,cell)
                    self.enemy.add(shooting_enemy_sprite)
                    Level.enemy = self.enemy
                if -200 >= cell >=  -299:   
                    self.coin_count += 1
                    self.coin_block = Coin((x,y),cell)
                    self.coin.add(self.coin_block)
                
    def scroll_x(self):
        player = self.player.sprite
        player_x = player.rect.centerx
        direction_x = player.direction.x

        if player_x < 300/new_pos_x and direction_x < 0:
            self.world_shift = 8/new_pos_x
            player.speed = 0

        elif player_x > original_screen_width - (300/new_pos_x) and direction_x > 0:
            self.world_shift = -8/new_pos_x
            player.speed = 0
        
        else:
            self.world_shift = 0
            player.speed = 8/new_pos_x
                
    def horizontal_movement_collision(self):
        player = self.player.sprite
        player.collision_rect.x += player.direction.x * player.speed

        for sprite in self.tiles.sprites():
            if sprite.rect.colliderect(player.collision_rect):
                if player.direction.x < 0:
                    player.collision_rect.left = sprite.rect.right
                    player.on_left = True
                    self.current_x = player.rect.left
                elif player.direction.x > 0:
                    player.collision_rect.right = sprite.rect.left
                    player.on_right = True
                    self.current_x = player.rect.right

    def vertical_movement_collision(self):
        player = self.player.sprite
        player.apply_gravity()

        for sprite in self.tiles.sprites():
            if sprite.rect.colliderect(player.collision_rect):
                if player.direction.y > 0:
                    player.collision_rect.bottom = sprite.rect.top
                    player.direction.y = 0
                    player.on_ground = True
                elif player.direction.y < 0:
                    player.collision_rect.top = sprite.rect.bottom
                    player.direction.y = 0 
                    player.on_celling = True
        
        if player.on_ground and player.direction.y < 0 or player.direction.y > 1:
            player.on_ground = False
        if player.on_celling and player.direction.y > 1:
            player.on_celling = False
        
    def finnish_collision(self):
        global finnish_state
        player = self.player.sprite
        if Finnish.rect.colliderect(player.rect):
            del(player.rect)
            finnish_state = True
        else: finnish_state = False

    def coin_collisions(self):
        player = self.player.sprite
        for sprite in self.coin.sprites():
            if sprite.rect.colliderect(player):
                self.coin_collected += 1
                sprite.kill()

    def coin_blit(self):
        self.font =  pygame.font.Font(None, int(36/new_pos_x)) 
        self.text = f"{self.coin_collected}/{self.coin_count}"
        self.text = self.font.render(self.text, True, (0, 255, 255))
        self.text_rect = self.text.get_rect(center=(200/new_pos_x,200/new_pos_y))
        screen.blit(self.text, self.text_rect)


    def run(self):
        # dust particles
        
        self.dust_sprite.update(self.world_shift)
        self.dust_sprite.draw(self.display_surface)

        # Level Tile
        draw_bg(self.world_shift)
        self.tiles.update(self.world_shift)
        self.tiles.draw(self.display_surface)
        self.scroll_x()
        
        # Finnish
        try:
            self.finnish.draw(self.display_surface)
            self.finnish.update(self.world_shift)
            self.finnish_collision()
        except: pass

        # Coin
        try:
            self.coin.draw(self.display_surface)
            self.coin.update(self.world_shift)
            self.coin_collisions()
            self.coin_blit()
        except: pass
       
        # player
        Level.player = self.player
        self.player.update()
        self.horizontal_movement_collision()
        self.get_player_on_ground()
        self.vertical_movement_collision()
        self.create_landing_dust()
        self.player.draw(self.display_surface)
        self.health_bar()

        # player bullet
        Level.bullet_group.draw(self.display_surface)
        Level.bullet_group.update()
        Level.tiles = self.tiles
        Level.enemy = self.enemy
        
        # enemy
        self.enemy.update(self.world_shift)
        self.enemy.draw(self.display_surface)
        
        # enemy bullet
        Level.enemy_bullet_group.draw(self.display_surface)
        Level.enemy_bullet_group.update(self.world_shift)     
    
#+ === Player ===
class Player(pygame.sprite.Sprite):
    def __init__(self,pos,surface,create_jump_particles,type,character):
        super().__init__()
        self.character = character
        self.import_character_assets()
        self.frame_index = 0
        self.animation_speed = 0.15
        self.image = self.animation['idle'][self.frame_index]
        self.rect = self.image.get_rect(topleft = pos)

        # dust particlas        
        self.import_dust_run_particles()
        self.dust_frame_index = 0
        self.dust_animation_speed = 0.15
        self.display_surface = surface
        self.create_jump_particles = create_jump_particles

        # Player Movement
        self.average_with_player = self.get_average_width()
        self.direction = pygame.math.Vector2(0,0)
        self.speed = 8/new_pos_x
        self.gravity = 0.8/new_pos_y
        self.jump_speed = -16/new_pos_y
        self.collision_rect = pygame.Rect(self.rect.topleft,(self.average_with_player,self.rect.height))

        # Player Status
        self.status = "idle"
        self.facing_right = True
        self.on_ground = False
        self.on_celling = False
        self.on_left = False
        self.on_right = False
        self.attack = False
        self.sword_range = 1
        self.player_type = type
        self.max_health = 10
        self.health = 10
        self.imunity = False
        self.imunity_time = 30
        self.attack_status = False
        self.melee_time = 0
        self.melee_reload_time = 0
        self.melee_attack_status = False 
    
    def get_average_width(self):
        self.rect_width = []
        for width in self.animation["idle"]:
            self.rect_width.append(width.get_width())
        return sum(self.rect_width) / len(self.rect_width)

    def imunity_countdown(self):
        if self.imunity == True:
            self.imunity_time -= 1
        if self.imunity_time <= 0:
            self.imunity = False
            self.imunity_time = 30

    def take_damage(self, damage):
        global dead
        self.health -= damage 
        if self.health <= 0:
            self.health = 0
            dead = True
       
    def enemy_collide_hitbox(self):  
        for sprite in Level.enemy.sprites():
            if sprite.rect.colliderect(self.rect):
                if self.imunity == False:
                    self.imunity = True
                    self.take_damage(2)
    
    def enemy_bullet_hitbox(self):
        for sprite in Level.enemy_bullet_group.sprites():
            if sprite.rect.colliderect(self.rect):
                if self.imunity == False:
                    self.imunity = True
                    self.take_damage(2)
                    sprite.kill()
                
    def import_character_assets(self):
        character_path = f"{script_path}/player/{self.character}/".replace("/", slash)
        self.animation = {"idle":[], "run":[], "jump":[], "fall":[], "attack":[]}
        for animation in self.animation.keys():
            full_path = character_path + animation
            self.animation[animation] = import_folder(full_path,True,animation)

    def import_dust_run_particles(self):
        self.dust_run_particles = import_folder(f"{script_path}/player/{self.character}/dust_particles/run".replace("/", slash))

    def run_dust_animation(self):
        if self.status == "run" and self.on_ground:
            self.dust_frame_index += self.dust_animation_speed
            if self.dust_frame_index >= len(self.dust_run_particles):
                self.dust_frame_index = 0
            
            dust_particlas = self.dust_run_particles[int(self.dust_frame_index)]

            if self.facing_right:
                pos = self.rect.bottomleft - pygame.math.Vector2(6/new_pos_x,10/new_pos_y)
                self.display_surface.blit(dust_particlas, pos)
            else:
                pos = self.rect.bottomright - pygame.math.Vector2(6/new_pos_x,10/new_pos_y)
                flip_dust_particlas = pygame.transform.flip(dust_particlas, True, False)
                self.display_surface.blit(flip_dust_particlas, pos)

    def animate(self):
        animation = self.animation[self.status]
        
        # loop over frame index
        self.frame_index += self.animation_speed
    
        if self.frame_index >= len(animation):
            self.frame_index = 0
        
        image = animation[int(self.frame_index)]
        if self.facing_right:
            self.image = image
            self.rect.bottomleft = self.collision_rect.bottomleft
        else:
            flipped_image = pygame.transform.flip(image, True, False)
            self.image = flipped_image
            self.rect.bottomright = self.collision_rect.bottomright

        # set the rect



        self.rect = self.image.get_rect(midbottom = self.rect.midbottom)
        
    def get_input(self):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_d]:
            self.direction.x = 1
            self.facing_right = True
        elif keys[pygame.K_a]:
            self.direction.x = -1
            self.facing_right = False
        else:
            self.direction.x = 0
        
        if keys[pygame.K_w] and self.on_ground:
            self.jump()
            self.create_jump_particles(self.rect.midbottom)

        

        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                self.frame_index = 0
                # melee attack
                if self.player_type == "melee" and self.melee_reload_time <= 0:
                    self.attack_status = True
                    self.melee_attack_status = True
                    self.melee_reload_time = 50
                else:
                    self.attack_status = False
                # range attack
                if self.player_type == "range": 
                    self.attack_status = True
                    if self.facing_right:                   
                        Level.bullet_group.add(Level.create_bullet(self,"right"))
                    elif self.facing_right == False:
                        Level.bullet_group.add(Level.create_bullet(self,"left"))
        
    def melee_attack(self):
        if self.melee_time  < 20:
            self.melee_time += 1
            if self.facing_right:
                self.melee_rect = pygame.Rect(self.rect.centerx, self.rect.y, 50/new_pos_x,  self.rect.height)
            elif self.facing_right == False:
                self.melee_rect = pygame.Rect(self.rect.centerx-50, self.rect.y, 60, self.rect.height)
            #pygame.draw.rect(self.display_surface,(0,255,0), self.melee_rect)
            self.melee_collision()
        else: 
            self.melee_attack_status = False
            self.melee_time = 0
        
    def melee_collision(self):
        for sprite in Level.enemy.sprites():
            if sprite.rect.colliderect(self.melee_rect):
                sprite.kill()

    def get_status(self):

        if self.attack_status and   self.frame_index > len(self.animation.get("attack"))-0.2:
            self.animation_speed= 0.15
            self.attack_status = False

        if self.attack_status and self.frame_index < len(self.animation.get("attack"))-0.2:
            self.status = "attack"       
            self.animation_speed = 0.05
        elif self.direction.y < 0:
            self.status = "jump"
        elif self.direction.y > 1:
            self.status = "fall"     
        else:
            if self.direction.x != 0:
                self.status = "run"     
            else:
                self.status = "idle"
                
    def apply_gravity(self):
        self.direction.y += self.gravity
        self.collision_rect.y += self.direction.y

    def jump(self):
        self.direction.y = self.jump_speed 
        
    def update(self):
        global dead
        if self.rect.y > 900/new_pos_y*new_pos_y: dead = True
        self.imunity_countdown()
        self.get_input()
        self.get_status()
        self.animate()
        self.run_dust_animation()
        try:
            self.enemy_collide_hitbox()
            self.enemy_bullet_hitbox()
        except:pass
        Player.max_health = self.max_health
        Player.health = self.health
        Player.rect = self.rect
        if self.melee_attack_status == True:
            self.melee_attack()
        self.melee_reload_time -= 1
        Player.imunity = self.imunity

class Bullet(pygame.sprite.Sprite,Level):
    def __init__(self, pos_x, pos_y, direction):
        super().__init__()
        self.pos_x = pos_x
        self.direction = direction
        self.image = pygame.Surface((10,10))
        self.image.fill((255,0,0))
        self.rect = self.image.get_rect(center = (pos_x, pos_y))

    
    def bullet_collision(self):
        for sprite in Level.tiles.sprites():
            if sprite.rect.colliderect(self.rect):
                self.kill()
        
        for sprite in Level.enemy.sprites():
            if sprite.rect.colliderect(self.rect):
                self.kill()
                sprite.kill()
        
    def update(self):
        # directions
        if self.direction == "left":
            self.rect.x -= 15/new_pos_x 
        elif self.direction == "right":
            self.rect.x += 15/new_pos_x
        
        # despawn bullet
        if self.rect.x - self.pos_x > 1200:
            self.kill()

        # collisons with tile
        self.bullet_collision()
        

#+ === Enemies ===
class WalkingEnemy(pygame.sprite.Sprite):
    def __init__(self,pos_x,pos_y,num):
        super().__init__()
        self.image_list = import_folder(f"{script_path}/enemies/{num}/walk".replace("/", slash),None,None,True)
        self.direction = pygame.math.Vector2(0,0)
        self.image = pygame.Surface((tile_size,tile_size),flags=pygame.SRCALPHA).convert_alpha()
        #self.image.fill((0,0,0))
        self.rect = self.image.get_rect(center = (pos_x, pos_y))
        self.gravity = 0.8/new_pos_y
        self.walk_direction = -1       # 1 == "right", -1 == "left"
        self.speed = 3
        self.enemy_ground = False
        self.hotizontal_collisions =False
        self.frame_index = 0
        self.animation_speed = 0.15

        # Help Box
        self.box_range = tile_size * self.walk_direction
        self.rect_block = pygame.Surface((tile_size,tile_size/2))
        self.rect_block.fill((255,0,0))
        self.help_rect = self.rect_block.get_rect(center = (pos_x+self.box_range, pos_y+10))

        self.rect_block_horizontal = pygame.Surface((tile_size*2,tile_size/2))
        self.rect_block_horizontal.fill((255,255,0))
        self.help_rect_horizontal = self.rect_block_horizontal.get_rect(center = (pos_x, pos_y-20))

    def animate(self):
        self.frame_index += self.animation_speed
        self.image_image = self.image_list[int(self.frame_index)]
        if self.walk_direction:
            self.image_img = self.image_image
        else:
            self.flipped_image = pygame.transform.flip(self.image_image, True, False)
            self.image_img = self.flipped_image

        self.image.blit(self.image_img ,(0,0))

    def apply_gravity(self):
        self.direction.y += self.gravity
        self.rect.y += self.direction.y
        self.help_rect.y += self.direction.y
        self.help_rect_horizontal.y += self.direction.y

    def vertical_movement_collision(self):    
        self.apply_gravity()
        self.tile_collidetect = []
        if self.hotizontal_collisions == True: self.hotizontal_collisions = False
        for sprite in Level.tiles.sprites():
            if sprite.rect.colliderect(self.rect):
                if self.direction.y > 0:
                    self.rect.bottom = sprite.rect.top
                    self.help_rect.bottom = sprite.rect.top+10
                    self.help_rect_horizontal.bottom = sprite.rect.top-20
                    self.direction.y = 0
                    self.enemy_ground = True

            self.tile_collidetect.append(sprite.rect.colliderect(self.help_rect))
        
        if True not in self.tile_collidetect and self.enemy_ground:
            if self.walk_direction == 1:
                self.walk_direction = -1
                self.help_rect.x -= tile_size*2
            elif self.walk_direction == -1:
                self.walk_direction = 1
                self.help_rect.x += tile_size*2
               
            self.box_range *= self.walk_direction

    def horizontal_movement_collision(self):
        for sprite in Level.tiles.sprites():
            if sprite.rect.colliderect(self.help_rect_horizontal):
                if self.walk_direction > 0: 
                    self.walk_direction = -1
                    self.help_rect.x -= tile_size*2
                elif self.walk_direction < 0: 
                    self.walk_direction = 1
                    self.help_rect.x += tile_size*2
                
    def walk(self):
        self.rect.x += self.speed * self.walk_direction
        self.help_rect.x = self.rect.x + tile_size/new_pos_x*self.walk_direction
        self.help_rect_horizontal.x += self.speed * self.walk_direction

    def update(self,shift_x):
        #pygame.draw.rect(screen,(255,0,0),self.help_rect)
        #pygame.draw.rect(screen,(255,0,255),self.help_rect_horizontal
        if self.frame_index >= len(self.image_list)-1:
            self.frame_index = 0
        self.animate()
        self.horizontal_movement_collision()
        self.vertical_movement_collision()
        if self.enemy_ground:
            self.walk()
        self.rect.x += shift_x
        self.help_rect.x += shift_x
        self.help_rect_horizontal.x += shift_x
        WalkingEnemy.rect = self.rect


class ShootingEnemy(pygame.sprite.Sprite):
    def __init__(self,pos_x,pos_y,num):
        super().__init__()
        self.direction = pygame.math.Vector2(0,0)
        self.image = pygame.Surface((tile_size,tile_size),flags=pygame.SRCALPHA).convert_alpha()
        #self.image.fill((0,0,255))
        self.rect = self.image.get_rect(center = ((pos_x+tile_size/2)/new_pos_x, pos_y))
        self.gravity = 0.2/new_pos_y
        self.pos_x, self.pos_y = (pos_x+tile_size/2)/new_pos_x, pos_y/new_pos_y
        self.frame_index_shoot = 0
        self.frame_index_stand = 0
        self.animation_speed = 0.05
        self.image_list_stand = import_folder(f"{script_path}/enemies/{num}/stand".replace("/", slash),None,None,True)
        self.image_list_shoot = import_folder(f"{script_path}/enemies/{num}/shoot".replace("/", slash),None,None,True)
       
        self.reload_time = 180 # 60 == 1s 
        self.reloading = int()
        self.shoot_point = pygame.math.Vector2(0,0)

    def animate(self):
        if self.reload_time-self.reloading <= 30:
            self.frame_index_shoot += self.animation_speed
            self.image_img = self.image_list_shoot[int(self.frame_index_shoot)]
        else:
            self.frame_index_stand += self.animation_speed
            self.image_img = self.image_list_stand[int(self.frame_index_stand)]

        self.image.blit(self.image_img ,(0,0))

    def apply_gravity(self):
        self.direction.y += self.gravity
        self.rect.y += self.direction.y

    def vertical_movement_collision(self):    
        self.apply_gravity()
      
        for sprite in Level.tiles.sprites():
            if sprite.rect.colliderect(self.rect):
                if self.direction.y > 0:
                    self.rect.bottom = sprite.rect.top
                    self.direction.y = 0

    def shoot(self):
        self.reloading += 1
        if self.reloading >= self.reload_time :          # pridat detect playera
            self.reloading = 0
            Level.enemy_bullet_group.add(self.bullet())

    def bullet(self):
        return EnemyBullet(self.rect.centerx,self.rect.centery,Player.rect.centerx,Player.rect.centery) 

    def update(self,shift_x):
        if self.frame_index_shoot >= len(self.image_list_shoot)-1:
            self.frame_index_shoot = 0
        if self.frame_index_stand >= len(self.image_list_stand)-1:
            self.frame_index_stand = 0
        self.animate()
        self.vertical_movement_collision()
        self.shoot()
        self.rect.x += shift_x
       

#+ === Enemy Assets ===
class EnemyBullet(pygame.sprite.Sprite,Level):
    def __init__(self, pos_x, pos_y,player_x,player_y):
        super().__init__()
        self.pos_x,self.pos_y = pos_x,pos_y
        self.image = pygame.Surface((10/new_pos_x,10/new_pos_y))
        self.image.fill((0,255,0))
        self.rect = self.image.get_rect(center = (pos_x, pos_y))
        self.bullet_speed = 15/new_pos_x
        self.bullet_x, self.bullet_y = pos_x, pos_y
        self.dest_x, self.dest_y = player_x,player_y
        self.move_x, self.move_y  = 0, 0
        self.new_dest_x,self.new_dest_y = 0,0
  
    def bullet_collision(self):
        for sprite in Level.tiles.sprites():
            if sprite.rect.colliderect(self.rect):
                self.kill()
        
        for sprite in Level.player.sprites():
            if sprite.rect.colliderect(self.rect) and Player.imunity:
                self.kill()
                


    def shoot(self):
        screen.blit(self.image, (self.bullet_x, self.bullet_y))
        # Calculate distance to destination
        dist = math.sqrt((self.dest_x - self.bullet_x) ** 2 + (self.dest_y - self.bullet_y) ** 2)

        # Calculate x and y movement
        if dist > self.bullet_speed:               
            self.move_x = (self.dest_x - self.bullet_x) / dist * self.bullet_speed 
            self.move_y = (self.dest_y - self.bullet_y) / dist * self.bullet_speed    
            self.bullet_x += self.move_x
            self.bullet_y += self.move_y
        else:             
            self.bullet_x = self.dest_x
            self.bullet_y = self.dest_y
            
        self.dest_x = self.bullet_x + self.move_x
        self.dest_y = self.bullet_y + self.move_y
        
    def update(self,shift_x):
        self.shift_x = shift_x
        self.rect.x, self.rect.y = self.bullet_x,self.bullet_y

        # despawn bullet
        if self.rect.x - self.pos_x > 900:
            self.kill()
        self.shoot()
        self.bullet_collision()


#+ === Level Finnish ===
class Finnish(pygame.sprite.Sprite):
    def __init__(self,pos,num):
        super().__init__()
        self.frame_index = 0
        self.animation_speed = 0.05
        self.num = num
        self.pos = pos
        self.image_list = import_folder(f"{script_path}/finnish/{self.num}".replace("/", slash)) 
        self.image = self.image_list[0]
        self.image = pygame.transform.scale(self.image_list[int(self.frame_index)], ((tile_size/new_pos_x),(tile_size/new_pos_y)))
        self.rect = self.image.get_rect(topleft = pos)
       
    def animation(self):
        self.pos = self.rect.bottom
        self.image = pygame.transform.scale(self.image_list[int(self.frame_index)], ((tile_size/new_pos_x),(tile_size/new_pos_y)))

    def update(self,x_shift):
        self.animation()
        self.frame_index += self.animation_speed
        self.rect.x += x_shift
        if self.frame_index >= len(self.image_list):
            self.frame_index = 0
        Finnish.rect = self.rect


#+ === Players Partical Effect ===
class ParticleEffect(pygame.sprite.Sprite):
    def __init__(self,pos,type,character):
        super().__init__()
        self.character = character
        self.frame_index = 0
        self.animation_speed = 0.5    
        if type == "jump":
            self.frames = import_folder(f"{script_path}/player/{self.character}/dust_particles/jump".replace("/", slash))
        if type == "land":
            self.frames = import_folder(f"{script_path}/player/{self.character}/dust_particles/land".replace("/", slash))
        self.image = self.frames[self.frame_index]
        self.rect = self.image.get_rect(center = pos)

    def animate(self):
        self.frame_index += self.animation_speed
        if self.frame_index >= len(self.frames):
            self.kill()
        else:
            self.image = self.frames[int(self.frame_index)]

    def update(self,x_shift):
        self.animate()
        self.rect.x += x_shift



#? === rest ===
def scale_pos():
    global new_pos_x, new_pos_y
    screen_width, screen_hight = screen.get_size()
    new_pos_x = (original_screen_width/screen_width)
    new_pos_y = (original_screen_hight/screen_hight)

def load_level():
    global level_map
    level_map = []

    for row in range(row_tile):
            r = [-1] * (col_tile * screen_reapeat)
            level_map.append(r)

    with open(f"{script_path}/files/level/{level_num}/data.csv".replace("/", slash), newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter = ',')
        for x, row in enumerate(reader):
            if x <= row_tile-1:
                for y, tile in enumerate(row):
                    level_map[x][y] = int(tile)
                    
    return level_map

def import_terrain_tile():
    # Count Block
    dir_path = f'{script_path}/block'
    count = 0
    for path in os.listdir(dir_path):
        if os.path.isfile(os.path.join(dir_path, path)):
            count += 1
    # Loading Blocks
    block_img_list = []
    for i in range(count):
        block_img = pygame.image.load(f"{script_path}/block/{i}.png".replace("/", slash)).convert_alpha()
        block_img_scale = pygame.transform.scale(block_img, (tile_size/new_pos_x,tile_size/new_pos_y))
        new_surf = pygame.Surface((tile_size/new_pos_x, tile_size/new_pos_y),flags=pygame.SRCALPHA).convert_alpha()
        new_surf.blit(block_img_scale,(0,0))
        block_img_list.append(new_surf)
    
    return block_img_list

player_hight_list ,player_width_list= [], []
def import_folder(path,player = False, animation = None,enemy = None):
    global player_hight_list ,player_width_list
    surface_list = []
    
    for _, __, img_file in walk(path):
        for image in img_file:
            full_path = path + "/" + image
            if image == ".DS_Store":
                pass
            else:
                if player == True:
                    if animation == "idle":
                        image_surf = pygame.image.load(full_path).convert_alpha()
                        img_rect_1 = image_surf.get_rect()
                        image_surf_scale = pygame.transform.scale(image_surf,((tile_size-3)/new_pos_x,(tile_size-3)/new_pos_y))
                        img_rect_2 = image_surf_scale.get_rect()
                        player_hight_list.append(((img_rect_1.height-img_rect_2.height)/img_rect_1.height)*100) # in %
                        player_width_list.append(((img_rect_1.width-img_rect_2.width)/img_rect_1.width)*100) # in %
                        surface_list.append(image_surf_scale)

                    else: 
                        player_hight, player_width = (sum(player_hight_list) / len(player_hight_list)), sum(player_width_list) / len(player_width_list) # in %
                        image_surf = pygame.image.load(full_path).convert_alpha()
                        img_rect = image_surf.get_rect()
                        #image_surf_scale = pygame.transform.scale(image_surf,((tile_size-3)/new_pos_x,(tile_size-3)/new_pos_y))
                        image_surf_scale = pygame.transform.scale(image_surf,((img_rect.width-(img_rect.width*player_width/100)),(img_rect.height-(img_rect.height*player_hight/100))))
                        surface_list.append(image_surf_scale)
                elif enemy:
                    image_surf = pygame.image.load(full_path).convert_alpha()
                    # Find the bounding box coordinates of the non-transparent pixels
                    bbox = image_surf.get_bounding_rect()
                    # Crop the image to the bounding box
                    cropped_surface = image_surf.subsurface(bbox)
                    image_surf_scale = pygame.transform.scale(cropped_surface,(((tile_size-3)/new_pos_x,(tile_size-3)/new_pos_y)))
                       
                    surface_list.append(image_surf_scale)
                        
                else:
                    image_surf = pygame.image.load(full_path).convert_alpha()
                    surface_list.append(image_surf)

    return surface_list

def import_bg():
    global background_img, count, BG_pos_y
    scale_pos()
    
    dir_path = f'{script_path}/background'.replace("/", slash )
    count = 0
    for path in os.listdir(dir_path):
        if os.path.isfile(os.path.join(dir_path, path)):
            count += 1

    with open(f"{script_path}/files/back_ground_pos.txt".replace("/", slash)) as f:
        BG_pos_y = [line.rstrip() for line in f]

    i = -1
    background_img = []
    for i in range(count):      
            img = pygame.image.load(f"{script_path}/background/{i}.png".replace("/", slash)).convert_alpha()
            background_img_scale = pygame.transform.scale(img, ((1300/new_pos_x),(730/new_pos_y)))
            background_img.append(background_img_scale)
  

def draw_bg(shift_x):
    global scrool
    if shift_x < 0:
        scrool -= 7.5/new_pos_x
    elif shift_x > 0:
        scrool += 7.5/new_pos_x
    
    bg_move = 0.3
    for i in range(count):
        bg_move += 0.1
        for x in range(screen_reapeat+2):
            screen.blit(background_img[i], ((x * background_img[i].get_width()+(scrool*bg_move)-300),0/new_pos_y+int(BG_pos_y[i])))
    
def load_button():
    global button_list, new_pos_x, new_pos_y
    button_list = []
    for i in range(23):
        img = pygame.image.load(f"{script_path}/button/{i}.png".replace("/", slash)).convert_alpha()
        size_x, size_y = 200, 50
        if 12 <= i <= 15: size_x, size_y = 50, 50
        elif 16 <= i <= 17: size_x, size_y = 200, 100
        elif 18 <= i <= 22: size_x, size_y = 1200, 700
        if i == 22: pass
        img_scale = pygame.transform.scale(img, ((size_x/new_pos_x),(size_y/new_pos_y)))
        button_list.append(img_scale)

#? === BUTON ===
class Button:
    def __init__(self, x,y, image, scale,animation = False, img_2 = 0):
        width = image.get_width()
        height = image.get_height()  
        self.image = pygame.transform.scale(image,(int(width*scale), int(height*scale)))
        self.rect = self.image.get_rect()
        self.rect.topleft = (x,y)
        # animations
        try:self.img_2 = pygame.transform.scale(img_2,(int(width*scale), int(height*scale)))
        except:pass
        self.animation = animation 
        self.ani = False

    def draw_button(self, surface):
        global click
        try:
            
            action = False
            pos = (-1,-1)
            pos = pygame.mouse.get_pos()
            if self.rect.collidepoint(pos):
                if pygame.mouse.get_pressed()[0] == 1 and click == False:
                    click = True
                    action = True   
                if self.animation:
                    self.ani = True
                    surface.blit(self.img_2, (self.rect.x, self.rect.y),)

            if pygame.mouse.get_pressed()[0] == False: click = False

            if self.ani == False:surface.blit(self.image, (self.rect.x, self.rect.y))
            return action
        except:pass
    
    def draw_button_v2(self, surface):
        global click
        try:
            action = False
            pos = (-1,-1)
            pos = pygame.mouse.get_pos()
            if self.rect.collidepoint(pos):
                if pygame.mouse.get_pressed()[0] == 1 and click == False: action = True   

            if pygame.mouse.get_pressed()[0] == False: click = False
            surface.blit(self.image, (self.rect.x, self.rect.y))
            return action
        except:pass


#! === Initializing === 
os_find()
scale_pos()
main_menu_loop()
