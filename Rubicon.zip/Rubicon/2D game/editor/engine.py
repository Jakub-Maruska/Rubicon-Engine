import button
import pygame, shutil, os, csv, platform
from datetime import datetime
from pygame.locals import *


x = 0
y = 30
os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (x,y)
pygame.init()

# === window ===
original_screen_width = 1920
original_screen_hight = 1080
screen = pygame.display.set_mode((original_screen_width, original_screen_hight), RESIZABLE)
pygame.display.set_caption("Game Engine")


# === Variable ===
clock = pygame.time.Clock()
fps = 60
keys = pygame.key.get_pressed()
exit = False
run = True
# --- --- --- ---
scroll = 0
scroll_left = False
scroll_right = False
scroll_speed = 1
# --- --- --- ---
tile_size = 46.666
original_tile_size = 46.666
row_tile = 15
col_tile = 28
screen_reapeat = 4
# --- --- --- ---
mouse_button_0_down = False
button_count = 0
current_block = 0
text_button_img_list = []
level_num = 1
bg_image_num = 0
world_data = []
player_num = 0
rect = "tile"
enemy_num = 0
finnish_num = 0
finnish_line_list = [[],[],[],[]]
load_project_page = 1
user_text = ""
rect_coler_input_name_active = pygame.Color("lightskyblue3")
rect_coler_input_name_passive = pygame.Color("grey15")
rect_coler_input_name = rect_coler_input_name_passive
active_input_name = False
bg_count = 0
block_page = 0
load_bacground = 0
language = "en"
button_language = 0


# text
text_list_en = ["Create a game!"]
text_list_sk = ["Vytvor si hru!"]
text_list_de = ["Spiel erstellen!!"]

# Tutorial Text
tutorial_text_list_en = ["Welcome to RUBICON,\n\nthe exciting 2D game engine! With RUBICON, you don't\nhave to be a programmer to bring your game ideas to life.\nAll you need are a few images and you'll be on your way\nto creating unique levels that are sure to keep your\n players entertained. So go ahead, Play it\nand unleash your creativity! ",
                "Create Folder\n\n1. Create your file by writing the name of your game.\n2. Press the next button to proceed to the next step.",
                "Finnish line & coin\n\nAdd an object to the level by dragging and dropping the\nimage of the Finnish line & coin. Finnish line will\nwork to win level for player, while the coin is a\nvaluable point that can be collected\n\nNote: you will add it to the level later. ",
                "Background\n\nAdd a background to the level by dragging\nand dropping an image. The background will only\nserve a visual purpose and will not affect gameplay.\n\nNote: you can add up to five layers.",
                "Block\n\nAdd blocks to the level by dragging and dropping images\nwithin the area marked by black and yellow strips.\nThese blocks will serve as platforms for the player.\n\nNote: you can add as many blocks as you like.",
                "Player\n\nChoose whether you want a melee or ranged player.\nThe next step will be to import images for animations.\n\nNote: you can choose to create additional players later. ",
                "Import\n\nby drag&drop import all images for player ",
                "Enemy\n\nChoose whether you want a walking or shooting enemy.\nThe next step will be to import images for animations.\n\nNote: you can choose to create additional enemies later. ",
                "Import\n\nby drag&drop import all images for enemy ",
                "Editor\n\n1. Arrows in the bottom left cornercan be usedt o switch\nbetween levels\n2. The three boxes at the bottom of the screen are used\nto select the finish line, player, and enemy in your game. \nOn the right side of your screen, you'll find a box with a\nblocks that can be use for create terain.",
                "Back Screen\n\nthis screen is used for orientation between different\nscreens and importing additional images"
                ]

tutorial_text_list_sk = ["Vitajte v RUBICONE,\n\n 2D game enigene! S RUBICONOM, nemusite byt programatorom,\naby ste preniesli vase napady hry do reality. Vsetko,\nco potrebujete, su par obrazkov a uz sa budete na ceste k\ntvorbe jedinecnych levelov, ktore urcite udrzia vasich\nhracov zabavenych. Takze chodte, hrajte a uvolnite svoju\nkreativitu!",
                        "Vytvorit priecinok\n\n1. Vytvorte svoj subor napisanim nazvu svojej hry.\n2. Stlacte tlacidlo dalej pre pokracovanie na dalsi krok.",
                        "Cielova ciara a mince\n\nPridajte objekt do levelu tahanim a presuvanim\nobrazka cielovej ciary a mince. Cielova ciara\numozni hracovi vyhrat level, zatial co minca je\nhodnotny bod, ktory moze byt zozbierany.\n\nPoznamka: pridate ju do levelu neskor.", 
                        "Pozadie\n\nPridajte pozadie do levelu tahanim a presuvanim\nobrazka. Pozadie bude sluzit iba na vizualny ucel\na nebude ovplyvnovat hratelnost.\n\nPoznamka: mozete pridat az pat vrstiev.", 
                        "Blok\n\nPridajte bloky do levelu tahanim a presuvanim\nobrazkov v oblasti oznacenej ciernymi a zltymi pruhmi.\nTieto bloky budu sluzit ako plosiny pre hraca.\n\nPoznamka: mozeete pridat kolko blokov chcete.", 
                        "Hrac\n\nZvolte, ci chcete hraca so zbranou na blizko alebo na dialku.\nDalsim krokom bude import obrazkov pre animacie.\n\nPoznamka: mozete si neskor zvolit vytvorenie dalsich hracov.", 
                        "Import\n\ntahanim a presuvanim importujte vsetky obrazky pre hraca.", 
                        "Nepriatel\n\nZvolte, ci chcete chodiaceho alebo strielajuceho nepriatela.\nDalsim krokom bude import obrazkov pre animacie.\n\nPoznamka: mozete si neskor zvolit vytvorenie dalsich nepriatelov.", 
                        "Import\n\ntahanim a presuvanim importujte vsetky obrazky pre nepriatela.", 
                        "Editor\n\n1. Sipky v lavom dolnom rohu mozete pouzit na prepinanie\nmedzi levelmi.\n2. Tri policka v dolnej casti obrazovky sluzia na vyber\nCielovej ciary, hraca a nepriatela vo vasej hre.\nNa pravej strane obrazovky najdete policko s blokmi,\nktoré mozete pouzit na vytvaranie terenu.",
                        "Navratova obrazovka\n\nTato obrazovka sa pouziva na orientaciu medzi roznymi\nobrazovkami a na importovanie dalsich obrazkov."
                        ]

tutorial_text_list_de = ["Willkommen bei RUBICON,\n\ndem aufregenden 2D-Spiel-Engine! Mit RUBICON müssen Sie\nkeinProgrammierer sein, um Ihre Spielideen zum Leben zu erwecken.\nAlles, was Sie brauchen, sind ein paar Bilder und schon\nkönnen Sie einzigartige Level erstellen, die sicherstellen,\ndass Ihre Spieler unterhalten werden. Also los, spielen Sie es\nund entfesseln Sie Ihre Kreativität! ", 
                        "Ordner erstellen\n\n1. Erstellen Sie Ihre Datei, indem Sie den Namen Ihres Spiels schreiben.\n2. Klicken Sie auf die nächste Schaltfläche, um zum nächsten Schritt zu gelangen.", 
                        "Ziellinie & Münze\n\nFügen Sie ein Objekt zum Level hinzu, indem Sie das Bild der Ziellinie & Münze ziehen und ablegen. Die Ziellinie\nwird dazu beitragen, das Level für den Spieler zu gewinnen, während die Münze ein wertvoller Punkt ist,\nder gesammelt werden kann.\n\nHinweis: Sie werden es später zum Level hinzufügen.", 
                        "Hintergrund\n\nFügen Sie dem Level einen Hintergrund hinzu, indem Sie ein Bild ziehen und ablegen. Der Hintergrund wird\nnur zu visuellen Zwecken dienen und das Gameplay nicht beeinflussen.\n\nHinweis: Sie können bis zu fünf Schichten hinzufügen.", 
                        "Block\n\nFügen Sie Blöcke zum Level hinzu, indem Sie Bilder innerhalb des Bereichs mit schwarz-gelben Streifen ziehen und ablegen.\nDiese Blöcke werden als Plattformen für den Spieler dienen.\n\nHinweis: Sie können so viele Blöcke hinzufügen, wie Sie möchten.", 
                        "Player\n\nWählen Sie, ob Sie einen Nahkampf- oder Fernkampfspieler möchten.\nDer nächste Schritt besteht darin, Bilder für Animationen zu importieren.\n\nHinweis: Sie können später zusätzliche Spieler erstellen. ", 
                        "Importieren\n\nDurch Drag & Drop importieren Sie alle Bilder für den Spieler.", 
                        "Feind\n\nWählen Sie, ob Sie einen laufenden oder schießenden Gegner möchten.\nDer nächste Schritt besteht darin, Bilder für Animationen zu importieren.\n\nHinweis: Sie können später zusätzliche Gegner erstellen. ", 
                        "Importieren\n\nDurch Drag & Drop importieren Sie alle Bilder für den Gegner.", 
                        "Editor\n\n1. Die Pfeile in der linken unteren Ecke können verwendet werden, um zwischen Leveln zu wechseln.\n2. Die drei Boxen am unteren Bildschirmrand werden verwendet,\num die Ziellinie, den Spieler und den Gegner in Ihrem Spiel auszuwählen.\nAuf der rechten Seite des Bildschirms finden Sie eine Box mit Blöcken,\ndie für die Erstellung von Gelände verwendet werden können.", 
                        "Hintergrundbildschirm\n\ndieser Bildschirm wird zur Orientierung zwischen verschiedenen\nBildschirmen und zum Importieren zusätzlicher Bilder verwendet."
                        ]


# Error text
error_text_list_en = ["import player error EN",
                      "Add at least 1 finnish line to contiue",
                      "Add at least 1 layer of background\nto contiue",
                      "Add at least 1 block to contiue",
                      "You have to add name of the project",
                      "This name of project is used\n\nmake a new one or choose you save",
                      "There is ERROR\n\n check if you imported images",
                      "You need import enemy images\n to contiue",
                      "You need import all enemy images\n to contiue",
                      "You need import all player images\n to contiue"
                      ]

error_text_list_sk = [ "chyba importu hraca",
                        "Pridaj aspon 1 cielovu vlajku pre pokracovanie", 
                        "Pridaj aspon 1 vrstvu pozadia pre pokracovanie", 
                        "Pridaj aspon 1 blok pre pokracovanie",
                        "Musis pridat nazov projektu", 
                        "Tento nazov projektu uz existuje,\n\nvytvor novy alebo zvol iny ulozeny",
                        "Nastala chyba,\n\nskontroluj, ci si importoval obrazky", 
                        "Musis importovat obrazky nepriatelov\npre pokracovanie", 
                        "Musis importovat vsetky obrazky nepriatelov\npre pokracovanie", 
                        "Musis importovat vsetky obrazky hraca\npre pokracovanie"
                      ]

error_text_list_de = ["Importfehler des Spielers ", 
                    "Füge mindestens 1 finnische Zeile hinzu, um fortzufahren", 
                    "Fügen Sie mindestens 1 Hintergrundebene hinzu,\num fortzufahren", 
                    "Fügen Sie mindestens 1 Block hinzu, um fortzufahren", 
                    "Sie müssen den Namen des Projekts hinzufügen", 
                    "Dieser Projektname wird bereits verwendet,\n\nerstellen Sie einen neuen oder wählen\nSie einen gespeicherten", 
                    "Es gibt einen FEHLER,\n\nüberprüfen Sie, ob Sie Bilder\nimportiert haben", 
                    "Sie müssen Bilder von Feinden importieren,\num fortzufahren", 
                    "Sie müssen alle Feindbilder importieren,\num fortzufahren", 
                    "Sie müssen alle Spielerbilder importieren,\num fortzufahren"
                    ]


script_path = os.path.dirname(os.path.abspath(__file__))
current_os = platform.system()  
if current_os == "Darwin":
    slash="/"
    script_path = script_path.replace("/editor","")
else:
    slash="\\"
    #script_path = script_path[:0] + "C" + script_path[1:]
    script_path = script_path.replace("\editor","")

my_font = f'{script_path}/editor/font.ttf'




# === Images load ===
buttons_list = ["x","X"]
buttons_list_v2 = ["x","X"]
for i in range(1,40):
        buttons_list.append(pygame.image.load(f"{script_path}/image/Button/Button/{i}_1.png".replace("/",slash)).convert_alpha())
        buttons_list_v2.append(pygame.image.load(f"{script_path}/image/Button/Button/{i}_2.png".replace("/",slash)).convert_alpha())


# Button (normal sate)
language_btn_img = pygame.image.load(f"{script_path}/image/Button/language_button.png".replace("/",slash)).convert_alpha()
en_btn_img =  pygame.image.load(f"{script_path}/image/Button/english_button.png".replace("/",slash)).convert_alpha()
sk_btn_img =  pygame.image.load(f"{script_path}/image/Button/slovak_button.png".replace("/",slash)).convert_alpha()
de_btn_img =  pygame.image.load(f"{script_path}/image/Button/german_button.png".replace("/",slash)).convert_alpha()
bin_btn_img =  pygame.image.load(f"{script_path}/image/Button/Kos_ikona.png".replace("/",slash)).convert_alpha()
left_arrow_btn_img = pygame.image.load(f"{script_path}/image/Button/left_arrow_btn.png".replace("/",slash)).convert_alpha()
right_arrow_btn_img = pygame.image.load(f"{script_path}/image/Button/right_arrow_btn.png".replace("/",slash)).convert_alpha()
plus_img_btn = pygame.image.load(f"{script_path}/image/Button/plus_button.png".replace("/",slash)).convert_alpha() 
melee_player_img = pygame.image.load(f"{script_path}/image/Button/melee_player_btn.png".replace("/",slash)).convert_alpha()
range_player_img = pygame.image.load(f"{script_path}/image/Button/range_player_btn.png".replace("/",slash)).convert_alpha()
walking_enemy_btn_img = pygame.image.load(f"{script_path}/image/Button/walking_enemy_btn_img.png".replace("/",slash)).convert_alpha()
range_enemy_btn_img = pygame.image.load(f"{script_path}/image/Button/range_enemy_btn_img.png".replace("/",slash)).convert_alpha()
folder_ikon_btn = pygame.image.load(f"{script_path}/image/Button/folder_ikon.png").convert_alpha()
# Button (animated)
folder_ikon_btn_v2 = pygame.image.load(f"{script_path}/image/Button/folder_ikon_v2.png").convert_alpha()
language_btn_img_v2 = pygame.image.load(f"{script_path}/image/Button/langauge_button_v2.png".replace("/",slash)).convert_alpha()
en_btn_img_v2 = pygame.image.load(f"{script_path}/image/Button/english_button_v2.png".replace("/",slash)).convert_alpha()
sk_btn_img_v2 = pygame.image.load(f"{script_path}/image/Button/slovak_button_v2.png".replace("/",slash)).convert_alpha()
de_btn_img_v2 =  pygame.image.load(f"{script_path}/image/Button/german_button_v2.png".replace("/",slash)).convert_alpha()
bin_btn_img_v2 = pygame.image.load(f"{script_path}/image/Button/Kos_ikona_v2.png".replace("/",slash)).convert_alpha()
left_arrow_btn_img_v2 = pygame.image.load(f"{script_path}/image/Button/left_arrow_btn_v2.png".replace("/",slash)).convert_alpha()
right_arrow_btn_img_v2 = pygame.image.load(f"{script_path}/image/Button/right_arrow_btn_v2.png".replace("/",slash)).convert_alpha()
plus_img_btn_v2 = pygame.image.load(f"{script_path}/image/Button/plus_button_v2.png".replace("/",slash)).convert_alpha() 
melee_player_img_v2 = pygame.image.load(f"{script_path}/image/Button/melee_player_btn_v2.png".replace("/",slash)).convert_alpha()
range_player_img_v2 = pygame.image.load(f"{script_path}/image/Button/range_player_btn_v2.png".replace("/",slash)).convert_alpha()
walking_enemy_btn_img_v2 = pygame.image.load(f"{script_path}/image/Button/walking_enemy_btn_img_v2.png".replace("/",slash)).convert_alpha()
range_enemy_btn_img_v2 = pygame.image.load(f"{script_path}/image/Button/range_enemy_btn_img_v2.png".replace("/",slash)).convert_alpha()
# Else
back_img_bg = pygame.image.load(f"{script_path}/image/Engin/back_screen.png".replace("/",slash)).convert_alpha()
language_change_bg_img = pygame.image.load(f"{script_path}/image/Engin/language_screen.png".replace("/",slash)).convert_alpha()
folder_delete_confimations_bg = pygame.image.load(f"{script_path}/image/Engin/confirm_screen.png".replace("/",slash)).convert_alpha()
import_shooting_enemy = pygame.image.load(f"{script_path}/image/Engin/shooting_enemy_bg.png".replace("/",slash)).convert_alpha()
import_walk_enemy = pygame.image.load(f"{script_path}/image/Engin/walk_import_bg.png".replace("/",slash)).convert_alpha()
logo_img = pygame.image.load(f"{script_path}/image/Engin/logo.png".replace("/",slash)).convert_alpha()
DragAndDrop_img = pygame.image.load(f"{script_path}/image/Engin/drag&drop.png".replace("/",slash)).convert_alpha()
engine_bg_img = pygame.image.load(f"{script_path}/image/Engin/editor_bg.png".replace("/",slash)).convert_alpha()
level_editor_bg_img = pygame.image.load(f"{script_path}/image/Engin/level_editor_bg.png".replace("/",slash)).convert_alpha()
dragdrop_img = pygame.image.load(f"{script_path}/image/Engin/drag&drop.png".replace("/",slash)).convert_alpha()
level_building_img = pygame.image.load(f"{script_path}/image/Engin/drag&drop.png".replace("/",slash)).convert_alpha()
import_finnish_line_bg = pygame.image.load(f"{script_path}/image/Engin/import_finish_screen.png".replace("/",slash)).convert_alpha()
new_project_screen = pygame.image.load(f"{script_path}/image/Engin/new_project_screen.png".replace("/",slash)).convert_alpha()
import_bg_bg_image = pygame.image.load(f"{script_path}/image/Engin/import_bg_bg.png".replace("/",slash)).convert_alpha()
player_choose_img = pygame.image.load(f"{script_path}/image/Engin/player_choose.png".replace("/",slash)).convert_alpha()
error_bg = pygame.image.load(f"{script_path}/image/Engin/error_screen.png".replace("/",slash)).convert_alpha()
import_block_bg_img = pygame.image.load(f"{script_path}/image/Engin/import_block_bg.png".replace("/",slash)).convert_alpha()
left_arrow_img = pygame.image.load(f"{script_path}/image/Button/left_arrow_btn.png".replace("/",slash))
right_arrow_img = pygame.image.load(f"{script_path}/image/Button/right_arrow_btn.png".replace("/",slash))
player_import_bg_img = pygame.image.load(f"{script_path}/image/Engin/player_import_bg.png".replace("/",slash)).convert_alpha() 
drag_drop_player_img = pygame.image.load(f"{script_path}/image/Engin/drag&drop.png".replace("/",slash)).convert_alpha() 
load_project_bg_img = pygame.image.load(f"{script_path}/image/Engin/save_screen.png".replace("/",slash))
tutorial_background_img = pygame.image.load(f"{script_path}/image/Engin/tutorial_screen.png".replace("/",slash))


#delete_img = pygame.image.load(f"{script_path}/image/Button/new_project_btn.png".replace("/",slash))
#load_text_img = pygame.image.load(f"{script_path}/image/Button/new_project_btn.png".replace("/",slash)).convert_alpha()
#choose_player_img = pygame.image.load(f"{script_path}/image/Button/yes_2.png".replace("/",slash)).convert_alpha()
#choose_enememies_img = pygame.image.load(f"{script_path}/image/Button/yes_2.png".replace("/",slash)).convert_alpha() 



#+=== === Init Func === ===
#*--- Scale ---
def scale_pos():
    global new_pos_x, new_pos_y, screen_hight, screen_width
    try:
        screen_width, screen_hight = screen.get_size()
        new_pos_x = (original_screen_width/screen_width)
        new_pos_y = (original_screen_hight/screen_hight)
    except:pass

#*--- Draw Button ---
def button_draw_new_poject():
    global back_btn_img, tutorial_btn_img, next_btn_img, new_pos_x, new_pos_y, back_btn, tutorial_btn, next_btn
    back_btn_img_scale = pygame.transform.scale(buttons_list[14+button_language], ((400/new_pos_x),(130/new_pos_y)))
    back_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[14+button_language], ((400/new_pos_x),(130/new_pos_y)))
    back_btn = button.Button(210/new_pos_x,835/new_pos_y, back_btn_img_scale, 1,True,back_btn_img_scale_v2)

    tutorial_btn_img_scale = pygame.transform.scale(buttons_list[20+button_language], ((400/new_pos_x),(130/new_pos_y)))
    tutorial_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[20+button_language], ((400/new_pos_x),(130/new_pos_y)))
    tutorial_btn = button.Button(760/new_pos_x,835/new_pos_y, tutorial_btn_img_scale, 1,True,tutorial_btn_img_scale_v2)

    next_btn_img_scale = pygame.transform.scale(buttons_list[17+button_language], ((400/new_pos_x),(130/new_pos_y)))
    next_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[17+button_language], ((400/new_pos_x),(130/new_pos_y)))
    next_btn = button.Button(1310/new_pos_x,835/new_pos_y, next_btn_img_scale, 1,True,next_btn_img_scale_v2)

#*delete .DS_Store file
def delete_ds_store(directory):
    for root, dirs, files in os.walk(directory):
        for filename in files:
            if filename == ".DS_Store":
                file_path = os.path.join(root, filename)
                os.remove(file_path)

#
#
#
#
#
#

#+== === TEXT Func === ===
#*--- Error ---
def error(type):
    global run
    error_class = Error(type)
    while run:
        clock.tick(fps)
        scale_pos()
        error_class.run()
        # exit
        for event in pygame.event.get():
                if event.type == pygame.QUIT or exit == True:
                    run = False
                    pygame.quit()

        close_btn_scale = pygame.transform.scale(buttons_list[26+button_language], ((430/new_pos_x),(100/new_pos_y)))
        close_btn_scale_v2 = pygame.transform.scale(buttons_list_v2[26+button_language], ((430/new_pos_x),(100/new_pos_y)))
        close_btn = button.Button(745/new_pos_x,650/new_pos_y, close_btn_scale, 1, True, close_btn_scale_v2)
        
        error_bg_scale = pygame.transform.scale(error_bg, ((1000/new_pos_x),(640/new_pos_y)))
        screen.blit(error_bg_scale, (460/new_pos_y,170/new_pos_y))

        # Blit the lines of text onto the screen
        for line_render, line_rect in zip(line_renders, line_rects):
            screen.blit(line_render, line_rect)


        if close_btn.draw_button(screen):
            break

        if run: pygame.display.update()

class Error:
    def __init__(self,text_type) -> None:
        if language == "en":
            self.text_list = error_text_list_en
        elif language == "sk":
            self.text_list = error_text_list_sk
        elif language == "de":
            self.text_list = error_text_list_de
        self.text = self.text_create(text_type)

    def text_create(self,text_type):
        if text_type == "text_imput":
            self.text_text = self.text_list[0]
        elif text_type == "finnish":
            self.text_text = self.text_list[1]
        elif text_type == "background":
            self.text_text = self.text_list[2]
        elif text_type == "block":
            self.text_text = self.text_list[3]
        elif text_type == "input":
            self.text_text = self.text_list[4]
        elif text_type == "input_exists":
            self.text_text = self.text_list[5]    
        elif text_type == "error":
            self.text_text = self.text_list[6]
        elif text_type == "walk_enemy":
            self.text_text = self.text_list[7]
        elif text_type == "shoot_enemy":
            self.text_text = self.text_list[8]
        elif text_type == "player_import":
            self.text_text = self.text_list[9]

        return self.text_text

    def text_palcing(self):
        global line_rects, line_renders
        self.font = pygame.font.Font(my_font, int(36/new_pos_x))
        self.lines = self.text.split("\n")
        line_renders = [self.font.render(line, True, (255, 0, 0)) for line in self.lines]
        line_rects = [line_render.get_rect() for line_render in line_renders]
        for i, line_rect in enumerate(line_rects):
            line_rect.center = (1920/new_pos_x / 2,  350 + i * self.font.get_linesize())

    def run(self):
        self.text_palcing()


#*--- Tutorial ---
def tutorial(text_type):
    global run
    tutorial_class = Tutorial(text_type)
    while run:
        clock.tick(fps)
        scale_pos()
        tutorial_class.run()
        # Exit
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()

        tutorial_background_img_scale = pygame.transform.scale(tutorial_background_img, ((1250/new_pos_x),(600/new_pos_y)))
        screen.blit(tutorial_background_img_scale, (360/new_pos_y,75/new_pos_y))
    

        # Blit the lines of text into the screen
        for line_render, line_rect in zip(line_renders, line_rects):
            screen.blit(line_render, line_rect)

        if i_undertand_btn.draw_button(screen):
            break

        if run: pygame.display.update()

class Tutorial:
    def __init__(self,text_type) -> None:
        if language == "en":
            self.text_list = tutorial_text_list_en
        elif language == "sk":
            self.text_list = tutorial_text_list_sk
        elif language == "de":
            self.text_list = tutorial_text_list_de
        self.text = self.text_create(text_type)

    def button_placing(self):
        global i_undertand_btn
        self.i_undertand_btn_img_scale = pygame.transform.scale(buttons_list[23+button_language], ((250/new_pos_x),(100/new_pos_y)))
        self.i_undertand_btn_img_v2_scale = pygame.transform.scale(buttons_list_v2[23+button_language], ((250/new_pos_x),(100/new_pos_y)))
        i_undertand_btn = button.Button(835/new_pos_x,520/new_pos_y, self.i_undertand_btn_img_scale, 1, True, self.i_undertand_btn_img_v2_scale)
    
    def text_create(self,text_type):
        if text_type == "main_menu":
            self.text_text = self.text_list[0]
        elif text_type == "file_create":
            self.text_text = self.text_list[1]
        elif text_type == "finnish_import":
            self.text_text = self.text_list[2]
        elif text_type == "background_import":
            self.text_text = self.text_list[3]
        elif text_type == "block_import":
            self.text_text = self.text_list[4]
        elif text_type == "player_choose":
            self.text_text = self.text_list[5]
        elif text_type == "player_import":
            self.text_text = self.text_list[6]
        elif text_type == "enemy_choose":
            self.text_text = self.text_list[7]
        elif text_type == "enemy_import":
            self.text_text = self.text_list[8]
        elif text_type == "editor":
            self.text_text = self.text_list[9]
        elif text_type == "back":
            self.text_text = self.text_list[10]
        return self.text_text

    def text_palcing(self):
        global line_rects, line_renders
        self.font = pygame.font.Font(my_font, int(30/new_pos_x))
        self.lines = self.text.split("\n")
        line_renders = [self.font.render(line, True, (255, 255, 255)) for line in self.lines]
        line_rects = [line_render.get_rect() for line_render in line_renders]
        for i, line_rect in enumerate(line_rects):
            line_rect.center = (1920/new_pos_x / 2,  200/new_pos_y + i * self.font.get_linesize())

      

    def run(self):
        self.button_placing()
        self.text_palcing()

#
#
#

#?=== change language === 
def change_language():
    global run, language,button_language
    change_language_class = ChangeLanguage()
    while run:
        clock.tick(fps)
        scale_pos()
        change_language_class.run()
        # exit
        for event in pygame.event.get():
                if event.type == pygame.QUIT or exit == True:
                    run = False
                    pygame.quit()

        language_change_bg = pygame.transform.scale(language_change_bg_img, ((1920/new_pos_x),(1080/new_pos_y)))
        screen.blit(language_change_bg, (0/new_pos_y,0/new_pos_y))

        if en_btn.draw_button(screen):
            language = "en"
            button_language = 0
            break

        if sk_btn.draw_button(screen):
            language = "sk"
            button_language = 1
            break

        if de_btn.draw_button(screen):
            language = "de"
            button_language = 2
            break

        if back_btn.draw_button(screen):
            break


        if run: pygame.display.update()

class ChangeLanguage:
    def button_placing(self):
        global en_btn, sk_btn,de_btn,back_btn
        self.en_btn_scale = pygame.transform.scale(en_btn_img, ((530/new_pos_x),(130/new_pos_y)))
        self.en_btn_scale_v2 = pygame.transform.scale(en_btn_img_v2, ((530/new_pos_x),(130/new_pos_y)))
        en_btn = button.Button(695/new_pos_x,150/new_pos_y, self.en_btn_scale, 1, True, self.en_btn_scale_v2)

        self.sk_btn_scale = pygame.transform.scale(sk_btn_img, ((530/new_pos_x),(130/new_pos_y)))
        self.sk_btn_scale_v2 = pygame.transform.scale(sk_btn_img_v2, ((530/new_pos_x),(130/new_pos_y)))
        sk_btn = button.Button(695/new_pos_x,350/new_pos_y, self.sk_btn_scale, 1, True, self.sk_btn_scale_v2)


        self.de_btn_scale = pygame.transform.scale(de_btn_img, ((530/new_pos_x),(130/new_pos_y)))
        self.de_btn_scale_v2 = pygame.transform.scale(de_btn_img_v2, ((530/new_pos_x),(130/new_pos_y)))
        de_btn = button.Button(695/new_pos_x,550/new_pos_y, self.de_btn_scale, 1, True, self.de_btn_scale_v2)

        self.back_btn_img_scale = pygame.transform.scale(buttons_list[14+button_language], ((400/new_pos_x),(130/new_pos_y)))
        self.back_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[14+button_language], ((400/new_pos_x),(130/new_pos_y)))
        back_btn = button.Button(770/new_pos_x,845/new_pos_y, self.back_btn_img_scale, 1,True,self.back_btn_img_scale_v2)

    def run(self):
        self.button_placing()

#
#
#
#
#
#

#+=== === Menu === ===
#*=== Loop === 
def menu_screen():
    global run, new_pos_x, exit, new_pos_y, screen_hight, screen_width, exit_btn_img, tutorial_btn_img, logo_img
    while run:
        clock.tick(fps)
        # - screen size update -
        scale_pos()
        # --- drawing & function ---
        draw_bg_menu()
        button_placing_manu()
        # - Button function -
        if settings_btn.draw_button(screen):
            change_language()
        if exit_btn.draw_button(screen):
            exit = True
        if new_project_btn.draw_button(screen):
            folder_create()
        if load_project_btn.draw_button(screen):
            load_project()
        if tutorial_btn.draw_button(screen):
            tutorial("main_menu")

        # - Exit -
        try:
            for event in pygame.event.get():
                if event.type == pygame.QUIT or exit == True:
                    run = False
                    pygame.quit()
        except:
            pass

        if run: pygame.display.update()

#*=== Funcions === 
# --- placing Button ---
def button_placing_manu():
    global new_project_btn, new_project_btn_ani_img, load_project_btn, load_project_btn_ani_img ,tutorial_btn,tutorial_btn_img_v2_scale, settings_btn, exit_btn,exit_btn_ani_img, tutorial_btn_img, exit_btn_img, settings_btn_img
    new_project_btn_img_scale = pygame.transform.scale(buttons_list[2+button_language], ((400/new_pos_x),(100/new_pos_y)))
    new_project_btn_img_v2_scale = pygame.transform.scale(buttons_list_v2[2+button_language], ((400/new_pos_x),(100/new_pos_y)))
    new_project_btn = button.Button(760/new_pos_x,275/new_pos_y, new_project_btn_img_scale, 1,True, new_project_btn_img_v2_scale)

    load_project_btn_img_scale = pygame.transform.scale(buttons_list[5+button_language], ((400/new_pos_x),(100/new_pos_y)))
    load_project_btn_img_v2_scale = pygame.transform.scale(buttons_list_v2[5+button_language], ((400/new_pos_x),(100/new_pos_y)))
    load_project_btn = button.Button(760/new_pos_x,440/new_pos_y, load_project_btn_img_scale, 1, True, load_project_btn_img_v2_scale )
 
    tutorial_btn_img_scale = pygame.transform.scale(buttons_list[20+button_language], ((400/new_pos_x),(100/new_pos_y)))
    tutorial_btn_img_v2_scale = pygame.transform.scale(buttons_list_v2[20+button_language], ((400/new_pos_x),(100/new_pos_y)))
    tutorial_btn = button.Button(760/new_pos_x,605/new_pos_y, tutorial_btn_img_scale, 1, True, tutorial_btn_img_v2_scale)

    settings_btn_img_scale = pygame.transform.scale(language_btn_img, ((75/new_pos_x),(75/new_pos_y)))
    settings_btn_img_v2_scale = pygame.transform.scale(language_btn_img_v2, ((75/new_pos_x),(75/new_pos_y)))
    settings_btn = button.Button(50/new_pos_x,900/new_pos_y, settings_btn_img_scale, 1, True, settings_btn_img_v2_scale)

    exit_btn_img_scale = pygame.transform.scale(buttons_list[11+button_language], ((200/new_pos_x),(100/new_pos_y)))
    exit_btn_img_v2_scale = pygame.transform.scale(buttons_list_v2[11+button_language], ((200/new_pos_x),(100/new_pos_y)))
    exit_btn = button.Button(860/new_pos_x,856/new_pos_y, exit_btn_img_scale, 1,True, exit_btn_img_v2_scale)

# --- Function for drawing BG ---
def draw_bg_menu():
    global logo_img, engine_bg_img
    screen.fill("orange",(0,0,screen_width,screen_hight))
    engine_bg_scale = pygame.transform.scale(engine_bg_img, ((1920/new_pos_x),(1080/new_pos_y)))
    screen.blit(engine_bg_scale, (0/new_pos_x,0/new_pos_y,))
    logo_img_scale = pygame.transform.scale(logo_img, ((360/new_pos_x),(100/new_pos_y)))
    screen.blit(logo_img_scale, (780/new_pos_x,140/new_pos_y,))

#
#
#
#
#
#

#+=== === NEW Project === ===
#!=== Folder name input === 
#*=== Loop === 
def folder_create():
    global run, bg_count, screen_hight,world_data, screen_width, base_font,x_mouse, y_mouse, user_text, new_pos_x, new_pos_y, input_name_rect,text_surface, active_input_name, rect_coler_input_name, icon_image_path
    world_data = []
    # create list of world
    while run:
        clock.tick(fps)
        new_project_screen_bg = pygame.transform.scale(new_project_screen, ((1920/new_pos_x),(1080/new_pos_y)))
        screen.blit(new_project_screen_bg, (0/new_pos_x,0/new_pos_y,))
        # - screen size update -
        scale_pos()
        # --- function ---
        button_draw_new_poject()
        folder_name_input()
        # --- for event ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                
                
        # --- folder name input ---
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_name_rect.collidepoint(event.pos):
                    active_input_name = True
                else:
                    active_input_name = False

            if event.type == pygame.KEYDOWN: 
                if active_input_name == True:
                    if event.key == pygame.K_BACKSPACE:
                        user_text = user_text[:-1]
                    else:
                        user_text += event.unicode
                        user_text = str(user_text)
            if active_input_name == True:
                rect_coler_input_name = rect_coler_input_name_active
            else:
                rect_coler_input_name = rect_coler_input_name_passive

        # --- input text ---
        text_surface = base_font.render(user_text,True,(255,255,255))
        if text_surface.get_width() > 390: 
            input_name_rect.w = text_surface.get_width() + 10   

        pygame.draw.rect(screen,rect_coler_input_name,  input_name_rect,2)
        screen.blit(text_surface,(input_name_rect.x + 5,input_name_rect.y + 8/new_pos_y))
        folder_path =  f"{script_path}/GameEngineSave/{user_text}"


        if language == "en":
            text_list = text_list_en
        elif language == "sk":
            text_list= text_list_sk
        elif language == "de":
            text_list = text_list_de

        font = pygame.font.Font(my_font, int(50/new_pos_x))
        text = font.render(text_list[0], True, (255, 255, 255))

        text_rect = text.get_rect()
        text_rect.center = (960 /new_pos_x, 340 /new_pos_y)

        screen.blit(text, (text_rect))

        # --- buttons ---
        if back_btn.draw_button(screen):
            menu_screen()
        if tutorial_btn.draw_button(screen):
            tutorial("file_create")
        if next_btn.draw_button(screen):
            if user_text == "":
                error("input")
            elif os.path.exists(folder_path):
                error("input_exists")
            else:
                new_folder_save()
                import_finish_line_screen()
                new_project_screen_import_bg()
              
        if run: pygame.display.update()

#*=== Funcions === 
# --- input folder name ---
def folder_name_input():
    global base_font, user_text, input_name_rect, text_surface
    input_name_rect = pygame.Rect(720/new_pos_x,400/new_pos_y,480/new_pos_x,60/new_pos_y)
    base_font = pygame.font.Font(my_font,int(35/new_pos_x))

# --- create folder ---
def new_folder_save():
    global user_text, world_data, bg_position_y
    try:
        with open(f"{script_path}/GameEngineSave/{user_text}/files/back_ground_pos.txt") as f:
            bg_position_y = [line.rstrip() for line in f]
            bg_position_y = [ int(x) for x in bg_position_y ]
    except:
        bg_position_y = [0,0,0,0,0]
    newpath = f'{script_path}/GameEngineSave/{user_text}' 
    newpath_coin = f'{script_path}/GameEngineSave/{user_text}/coin' 
    newpath_background = f'{script_path}/GameEngineSave/{user_text}/background' 
    newpath_block = f'{script_path}/GameEngineSave/{user_text}/block' 
    newpath_player = f'{script_path}/GameEngineSave/{user_text}/player' 
    newpath_enemies = f'{script_path}/GameEngineSave/{user_text}/enemies' 
    newpath_decoration = f'{script_path}/GameEngineSave/{user_text}/decoration' 
    newpath_files = f'{script_path}/GameEngineSave/{user_text}/files' 
    newpath_level = f'{script_path}/GameEngineSave/{user_text}/files/level' 
    newpath_level_num = f'{script_path}/GameEngineSave/{user_text}/files/level/1' 
    button_folder = f'{script_path}/GameEngineSave/{user_text}/button' 
    finnish_folder = f'{script_path}/GameEngineSave/{user_text}/finnish' 
    game_save_path = f"{script_path}/GameEngineSave/{user_text}/files/GameSave"
    if not os.path.exists(newpath):
        os.makedirs(newpath)
        os.makedirs(newpath_coin)
        os.makedirs(newpath_background)
        os.makedirs(newpath_block)
        os.makedirs(newpath_player)
        os.makedirs(newpath_enemies)
        os.makedirs(newpath_decoration)
        os.makedirs(newpath_files)
        os.makedirs(game_save_path)
        os.makedirs(newpath_level)
        os.makedirs(newpath_level_num)
        os.makedirs(button_folder)
        os.makedirs(finnish_folder)

        # -- create world list --
        for row in range(row_tile):
            r = [-1] * (col_tile * screen_reapeat)
            world_data.append(r)
        # ground
        for tile in range(0, (col_tile*screen_reapeat)):
            world_data[row_tile - 1][tile] = 0
        # save it
        save()

        # copy image img
        shutil.copytree(f'{script_path}/editor/game_core_image/image', f"{script_path}/GameEngineSave/{user_text}/files/image",dirs_exist_ok=True)
        # copy button img
        shutil.copytree(f'{script_path}/editor/game_core_image/button', f"{script_path}/GameEngineSave/{user_text}/button",dirs_exist_ok=True)
        # copy game core
        shutil.copy(f"{script_path}/editor/Game_Core.py", f"{script_path}/GameEngineSave/{user_text}")
    else:
        pass

#
#
#
#
#
#

#+=== === Import (1. STEP) === ===
#!=== Import FinnishLine/Coin === 
#*=== Loop === 
def import_finish_line_screen(back_status = False):
    global run,place_width,place_hight,place_x_list
    reload_finnish_line()
    finnish_1 = Finnish_animate(0)
    finnish_2 = Finnish_animate(1)
    while run:
        delete_ds_store(script_path)
        clock.tick(fps)
        # - screen size update -
        place_width = 600/new_pos_x
        place_hight = 600/new_pos_y
        scale_pos()
        button_draw_new_poject()
        import_finnish_line_bg_scale = pygame.transform.scale(import_finnish_line_bg, ((1920/new_pos_x),(1080/new_pos_y)))
        screen.blit(import_finnish_line_bg_scale, (0/new_pos_x,0/new_pos_y))
        # --- drawing & function ---
    
        place_x_list = [210/new_pos_x, 1110/new_pos_x]
        place_y = 115/new_pos_y
     
        # --- for Event ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                run = False
            if event.type == pygame.DROPFILE:
                x_y_mouse = pygame.mouse.get_pos()
                x_mouse = int(x_y_mouse[0])
                y_mouse = int(x_y_mouse[1])
                #? Finnish
                if place_x_list[0] <= x_mouse <= place_width+place_x_list[0] and place_y <= y_mouse <= place_hight+place_y:  
                    img = str(event)
                    folder_name = f"{script_path}/GameEngineSave/{user_text}/finnish/-100".replace("/",slash)
                    if not os.path.exists(folder_name):
                        os.makedirs(folder_name)
                    import_finnish_line(-100,img,folder_name)  
                #? Coin
                elif place_x_list[1] <= x_mouse <= place_width+place_x_list[1] and place_y <= y_mouse <= place_hight+place_y:  
                    img = str(event)
                    folder_name = f"{script_path}/GameEngineSave/{user_text}/coin/-200".replace("/",slash)
                    if not os.path.exists(folder_name):
                        os.makedirs(folder_name)
                    import_finnish_line(-200,img,folder_name)  
     
        dragdrop_img_scale = pygame.transform.scale(dragdrop_img, ((600-130)/new_pos_x,(600-130)/new_pos_y))
        screen.blit(dragdrop_img_scale,(place_x_list[0]+50/new_pos_x,place_y+95/new_pos_y))       
        screen.blit(dragdrop_img_scale,(place_x_list[1]+50/new_pos_x,place_y+95/new_pos_y))    
 
        finnish_1.run()
        finnish_2.run()

        delete_finnish_line()
         # - Button  function -
        
        if back_btn.draw_button(screen):
            if back_status == False:
                folder_create()
            else:
                back_screen()
        if tutorial_btn.draw_button(screen):
            tutorial("finnish_import")
        dir_path = f"{script_path}/GameEngineSave/{user_text}/finnish/-100"
        if next_btn.draw_button(screen):
            if back_status == False:
                if os.path.exists(dir_path):
                    new_project_screen_import_bg()
                else: error("finnish")
            else:
                if os.path.exists(dir_path):
                    back_screen()
                else: error("finnish")

        #reload_finnish_line()
        if run: pygame.display.update()

#*=== Funcions === 
# --- delete finnish ---
def delete_finnish_line():
    finnish_path = f"{script_path}/GameEngineSave/{user_text}/finnish/-100".replace("/",slash)    
    coin_path = f"{script_path}/GameEngineSave/{user_text}/coin/-200".replace("/",slash)
    finnsih_delete_btn,coin_delete_btn = [], []
    
    if os.path.exists(finnish_path):
        delete_img_scale = pygame.transform.scale(buttons_list[35+button_language], ((200/new_pos_x),(50/new_pos_y)))
        delete_img_scale_v2 = pygame.transform.scale(buttons_list_v2[35+button_language], ((200/new_pos_x),(50/new_pos_y)))
        finnsih_delete_btn_btn= button.Button(410/new_pos_x, 650/new_pos_y,delete_img_scale, 1,True,delete_img_scale_v2)
        finnsih_delete_btn.append(finnsih_delete_btn_btn)

    if os.path.exists(coin_path):
        delete_img_scale = pygame.transform.scale(buttons_list[35+button_language], ((200/new_pos_x),(50/new_pos_y)))
        delete_img_scale_v2 = pygame.transform.scale(buttons_list_v2[35+button_language], ((200/new_pos_x),(50/new_pos_y)))
        coin_delete_btn_btn = button.Button(1310/new_pos_x, 650 /new_pos_y,delete_img_scale, 1,True,delete_img_scale_v2)
        coin_delete_btn.append(coin_delete_btn_btn)

    for _,i in enumerate(coin_delete_btn):
        if i.draw_button(screen):
            path = f"{script_path}/GameEngineSave/{user_text}/coin/-200".replace("/",slash)
            shutil.rmtree(path)
            reload_finnish_line()

    for _,i in enumerate(finnsih_delete_btn):
        if i.draw_button(screen):
            path = f"{script_path}/GameEngineSave/{user_text}/finnish/-100".replace("/",slash)
            shutil.rmtree(path)
            reload_finnish_line()

# --- import finnish ---
def import_finnish_line(folder_nun,img_path,path):   
    img_number = len([f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))])       
    original= r"A"
    target = f"{path}/{img_number}.png".replace("/",slash)
    original = original.replace("A",(img_path[31:-4:]))
    image = pygame.image.load(original)

    image_rect = image.get_bounding_rect()
    crop_rect = pygame.Rect(image_rect.x, image_rect.y, image_rect.width, image_rect.height)
    cropped_image = image.subsurface(crop_rect)
    pygame.image.save(cropped_image, target)

    target = f"{path}/{img_number}.png".replace("/",slash)
    img = pygame.image.load(target).convert_alpha()
    if folder_nun == -100:
        finnish_line_list[0].append(img)
    if folder_nun == -200:
        finnish_line_list[1].append(img)


def reload_finnish_line():
    global finnish_line_list
    finnish_line_list = [[],[]]
    
    #? Finnish
    folder_path = f"{script_path}/GameEngineSave/{user_text}/finnish/-100"
    if os.path.exists(folder_path):
        image_num = len([f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))])
        for x in range(image_num):
            target = f"{script_path}/GameEngineSave/{user_text}/finnish/-100/{x}.png".replace("/",slash)
            img = pygame.image.load(target).convert_alpha()
            finnish_line_list[0].append(img)
    #? Coin
    folder_path = f"{script_path}/GameEngineSave/{user_text}/coin/-200"
    if os.path.exists(folder_path):
        image_num = len([f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))])
        for x in range(image_num):
            target = f"{script_path}/GameEngineSave/{user_text}/coin/-200/{x}.png".replace("/",slash)
            img = pygame.image.load(target).convert_alpha()
            finnish_line_list[1].append(img)

class Finnish_animate:
    def __init__(self,num):
        self.animations_speed = 0.15
        self.img_index = 0
        self.num = num
       
    def animate(self):
            try:   
                img = pygame.transform.scale(finnish_line_list[self.num][int(self.img_index)], (535/new_pos_x,535/new_pos_y))
                screen.blit(img, (place_x_list[self.num], 185/new_pos_y))
            except:pass

    def run(self):
        self.img_index += self.animations_speed
        if self.img_index > len(finnish_line_list[self.num]):
            self.img_index = 0
        self.animate()
  
#
#
#

#!=== Inport BG Main Loop === 
#*=== Loop === 
def new_project_screen_import_bg(back_status = False):
    global run, screen_hight, screen_width, bg_image_path, x_y_mouse, x_mouse ,y_mouse, world_data, new_pos_x, new_pos_y, back_btn, tutorial_btn, next_btn 
   
    while run:
        bug_file_del_bg()
        delete_ds_store(script_path)
        clock.tick(fps)
        screen.fill("#0e395b",(0,0,screen_width,screen_hight))
        # - screen size update -
        scale_pos()
        # --- drawing & function ---
        dysplay_BG()
        bg_import_bg()
        bg_button()
        button_draw_new_poject()
         # - count number of file in folder - 
        file_path = f'{script_path}/GameEngineSave/{user_text}/background'.replace("/", slash)
        bg_count = 0
        for path in os.listdir(file_path):
            if os.path.isfile(os.path.join(file_path, path)):
                bg_count += 1
     
        # --- for Event ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                run = False
            

            if bg_count < 5:
                if event.type == pygame.DROPFILE:
                    x_y_mouse = pygame.mouse.get_pos()
                    x_mouse = int(x_y_mouse[0])*new_pos_x
                    y_mouse = int(x_y_mouse[1])*new_pos_y
                    if 75 <= x_mouse <= 1375 and 85 <= y_mouse <= 750 and bg_image_num <=5:  
                        bg_image_path = str(event)
                        import_bg_img()
                    else:
                        error("max_backgorund")
        
        # - Button  function -
        if back_btn.draw_button(screen):
            if back_status == False:
                import_finish_line_screen()
            else: back_screen()
        if tutorial_btn.draw_button(screen):
            tutorial("background_import")
        if next_btn.draw_button(screen):
            if back_status == False:           
                if number_of_bg > 0:
                    import_block_screen()
                elif number_of_bg <= 0:
                    error("background")
            else:
                if number_of_bg > 0:
                    back_screen()
                elif number_of_bg <= 0:
                    error("background")

        if run: pygame.display.update()

#*=== Funcions === 
# --- importing BG ---
def import_bg_img():
    global bg_image_num , bg_image_path
    # - count number of file in folder - 
    
    file_path = f'{script_path}/GameEngineSave/{user_text}/background'.replace("/",slash)
    bg_image_num = 0
    for path in os.listdir(file_path):
        if os.path.isfile(os.path.join(file_path, path)):
            bg_image_num += 1
    # - copy and paste file -        
    original= r"A"
    original = original.replace("A",(bg_image_path[31:-4:]))
    target = f"{script_path}/GameEngineSave/{user_text}/background/{bg_image_num}.png".replace("/",slash)

    if bg_image_num <5:
        image = pygame.image.load(original)
        pygame.image.save(image, target)
   
# ---- delete bug file ("1 2.png")
def bug_file_del_bg():
    folder_path = f'{script_path}/GameEngineSave/{user_text}/background'.replace("/",slash)
    for dirpath, _, filenames in os.walk(folder_path):
        for file_name in filenames:
            if " " in file_name:
                file_path = os.path.join(dirpath, file_name)
                os.remove(file_path)

# --- Draw BG ---
def bg_import_bg():
    global import_bg_bg_image, new_pos_x, new_pos_y
    import_bg_bg_image_scale = pygame.transform.scale(import_bg_bg_image, ((1920/new_pos_x),(1080/new_pos_y)))
    screen.blit(import_bg_bg_image_scale, (0/new_pos_x,0/new_pos_y))

# --- BG buttons ---
def bg_button():
    global delete_btn_list, number_of_bg, number_of_bg
    # delete
    for button_count_bg,i in enumerate(delete_btn_list):
        if i.draw_button(screen): 
            current_block_bg = button_count_bg
            # delete
            os.remove(f"{script_path}/GameEngineSave/{user_text}/background/{current_block_bg}.png".replace("/",slash))
            # renameing
            for x in range(number_of_bg):
                try:
                    old_name = f"{script_path}/GameEngineSave/{user_text}/background/{(current_block_bg+x+1)}.png".replace("/",slash)
                    new_name = f"{script_path}/GameEngineSave/{user_text}/background/{(current_block_bg+x)}.png".replace("/",slash)
                    os.rename(old_name, new_name)
                except:
                    pass


    # --- Button for moving import BG ---
    # loading blocks
    left_arrow_button_list = []
    right_arrow_button_list = []
   
    for i in range(number_of_bg):
        
        left_arrow_img_scale = pygame.transform.scale(left_arrow_btn_img, ((100/new_pos_x),(100/new_pos_y)))
        left_arrow_img_scale_v2 = pygame.transform.scale(left_arrow_btn_img_v2, ((100/new_pos_x),(100/new_pos_y)))
        left_arrow_button =  button.Button(1510 /new_pos_x, (118 + (113 * i))/new_pos_y, left_arrow_img_scale, 1,True, left_arrow_img_scale_v2)
        left_arrow_button_list.append(left_arrow_button)
        

        right_arrow_img_scale = pygame.transform.scale(right_arrow_img, ((100/new_pos_x),(100/new_pos_y)))
        right_arrow_img_scale_v2 = pygame.transform.scale(right_arrow_btn_img_v2, ((100/new_pos_x),(100/new_pos_y)))
        right_arrow_button =  button.Button(1620 /new_pos_x, (118 + (113 * i))/new_pos_y, right_arrow_img_scale, 1,True,right_arrow_img_scale_v2)
        right_arrow_button_list.append(right_arrow_button)
        

    
    # change positions
    for button_count,i in enumerate(left_arrow_button_list):
        if i.draw_button(screen):
            bg_position_y[button_count] -= 10


    for button_count,i in enumerate(right_arrow_button_list):
        if i.draw_button(screen):
            bg_position_y[button_count] += 10
   
    f = open(f"{script_path}/GameEngineSave/{user_text}/files/back_ground_pos.txt", "w")
    for i in range(len(bg_position_y)):
        f.write(f"{str(bg_position_y[i])}\n")
    f.close

#
#
#

#!=== Inport Blocks Main Loop ===
#*=== Loop === 
def import_block_screen(back_status = False):
    global run, screen_width, screen_hight , block_image_path, new_pos_x, new_pos_y,import_block_bg_img
    while run:
        delete_ds_store(script_path)
        bug_file_del()
        file_path = f'{script_path}/GameEngineSave/{user_text}/block'
        if os.path.isdir(file_path):
            ds_store_path = f'{script_path}/GameEngineSave/{user_text}/block/.DS_Store'
            if os.path.exists(ds_store_path):
                os.remove(ds_store_path)
        block_image_num = 0
        for path in os.listdir(file_path):
            
            if os.path.isfile(os.path.join(file_path, path)):
                block_image_num += 1
        clock.tick(fps)
        #screen.fill("blue",(0,0,screen_width,screen_hight))
        import_block_bg = pygame.transform.scale(import_block_bg_img, ((1920/new_pos_x),(1080/new_pos_y)))
        screen.blit(import_block_bg, (0/new_pos_x,0/new_pos_y))
        # - screen size update -
        scale_pos()
        # --- drawing & function ---
        dysplay_delete_block()
        button_draw_new_poject()
        # --- for Event ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                run = False
            if event.type == pygame.DROPFILE:
                x_y_mouse = pygame.mouse.get_pos()
                x_mouse = int(x_y_mouse[0])*new_pos_x
                y_mouse = int(x_y_mouse[1])*new_pos_y
                if 70 <= x_mouse <= 1850 and 150 <= y_mouse <= 630:
                    block_image_path = str(event)
                    import_block_img()
        
        # - Button  function -
        if back_btn.draw_button(screen):
            if back_status == False:
                new_project_screen_import_bg()
            else: back_screen()
        if tutorial_btn.draw_button(screen):
            tutorial("block_import")
        
        filename = f"{script_path}/GameEngineSave/{user_text}/block/0.png"
        if next_btn.draw_button(screen):
            if back_status == False:            
                if os.path.exists(filename):
                    choose_player_type_screen()
                else: error("block")
            else: 
                if os.path.exists(filename):
                    back_screen()
                else: error("block")

        if run: pygame.display.update()

#*=== Funcions === 
# --- dysplay and delete imported image ---
def dysplay_delete_block():
    global block_page, world_data
    left_arrow_btn_img_scale = pygame.transform.scale(left_arrow_btn_img, ((80/new_pos_x),(80/new_pos_y)))
    left_arrow_btn_img_scale_v2 = pygame.transform.scale(left_arrow_btn_img_v2, ((80/new_pos_x),(80/new_pos_y)))
    left_arrow_btn = button.Button(830/new_pos_x,640/new_pos_y, left_arrow_btn_img_scale, 1,True,left_arrow_btn_img_scale_v2)

    right_arrow_btn_img_scale = pygame.transform.scale(right_arrow_btn_img, ((80/new_pos_x),(80/new_pos_y)))
    right_arrow_btn_img_scale_v2 = pygame.transform.scale(right_arrow_btn_img_v2, ((80/new_pos_x),(80/new_pos_y)))
    right_arrow_btn = button.Button(1010/new_pos_x,640/new_pos_y, right_arrow_btn_img_scale, 1,True,right_arrow_btn_img_scale_v2)
    # - block drawing -
    # count block
    dir_path = f'{script_path}/GameEngineSave/{user_text}/block'
    count = 0
    for path in os.listdir(dir_path):
        if os.path.isfile(os.path.join(dir_path, path)):
            count += 1
    # loading blocks
    block_img_list = []
    delete_img_list = []   
    
    for i in range(count):
        try:
            block_img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/block/{i}.png".replace("/",slash))
            block_img_scale = pygame.transform.scale(block_img, (((300)/new_pos_x),(300/new_pos_y)))
            block_img_list.append(block_img_scale)

            delete_img_scale = pygame.transform.scale(buttons_list[35+button_language], ((150/new_pos_x),(50/new_pos_y)))
            delete_img_list.append(delete_img_scale)
        except:pass

        
    if len(block_img_list)-block_page <= 5:
        block_num = len(block_img_list)-block_page
    else:
        block_num = 5
        

    # dysplay block
    delete_btn_list = []
    for i in range(block_num):
        screen.blit(block_img_list[i+block_page], (( 90+(360*i))/new_pos_x ,(250/new_pos_y )))
        delete_img_scale_V2 = pygame.transform.scale(buttons_list_v2[35+button_language], ((150/new_pos_x),(50/new_pos_y)))
        delete_img_btn = button.Button((165 + 360*i )/new_pos_x, (500 )/new_pos_y,delete_img_list[i+block_page], 1,True,delete_img_scale_V2)
        delete_btn_list.append(delete_img_btn)

    # dysplay button
    for button_count,i in enumerate(delete_btn_list):
        if i.draw_button(screen): 
            current_block = button_count+block_page
            os.remove(f"{script_path}/GameEngineSave/{user_text}/block/{current_block}.png".replace("/",slash))
            for x in range(count):
                    try:
                        old_name = f"{script_path}/GameEngineSave/{user_text}/block/{current_block+x+1}.png".replace("/",slash)
                        new_name = f"{script_path}/GameEngineSave/{user_text}/block/{current_block+x}.png".replace("/",slash)
                        os.rename(old_name, new_name)
                    except:pass
               
            try:
                for y, row in enumerate(world_data):
                    for x, tile in enumerate(row):
                        if world_data[x][y] == current_block:
                            world_data[x][y] = -1
                            
                        elif world_data[x][y] > current_block:
                            world_data[x][y] = int(tile) - 1
                save()
            except:
                pass
                
    # - Button  function -
    if left_arrow_btn.draw_button(screen) and block_page != 0:
        block_page -= 5

    if right_arrow_btn.draw_button(screen) and  block_page/5+1 <= len(block_img_list)/5:
        block_page += 5

# --- import block function ---
def import_block_img():
    global block_image_num , block_image_path
    # - count number of file in folder - 
    file_path = f'{script_path}/GameEngineSave/{user_text}/block'
    block_image_num = 0
    for path in os.listdir(file_path):
        if os.path.isfile(os.path.join(file_path, path)):
            block_image_num += 1
    # - copy and paste file -        
    original= r"A"
    target = f"{script_path}/GameEngineSave/{user_text}/block/{block_image_num}.png".replace("/",slash)
    original = original.replace("A",(block_image_path[31:-4:]))
    image = pygame.image.load(original)
    image_rect = image.get_bounding_rect()
    crop_rect = pygame.Rect(image_rect.x, image_rect.y, image_rect.width, image_rect.height)
    cropped_image = image.subsurface(crop_rect)
    pygame.image.save(cropped_image, target)

# --- dysplay BG when import BG --- 
def dysplay_BG():
    global bg_count, new_pos_x, new_pos_y, bg_position_y, delete_btn_list, number_of_bg
    DragAndDrop_img_scale= pygame.transform.scale(DragAndDrop_img, ((1000/new_pos_x),(500/new_pos_y)))
    screen.blit(DragAndDrop_img_scale, ( 150/new_pos_x ,170/new_pos_x ))
    # - landscape drawing -
    try:
        with open(f"{script_path}/GameEngineSave/{user_text}/files/back_ground_pos.txt") as f:
            bg_position_y = [line.rstrip() for line in f]
            bg_position_y = [ int(x) for x in bg_position_y ]
    except:
        bg_position_y = [0,0,0,0,0]
    # count variations
    dir_path = f'{script_path}/GameEngineSave/{user_text}/background'
    number_of_bg = 0
    for path in os.listdir(dir_path):
        if os.path.isfile(os.path.join(dir_path, path)):
            number_of_bg += 1
  
    # loading bg
    delete_btn_list = []
    try:
        i = -1
        for i in range(number_of_bg):
            #for _ in range(screen_reapeat):
                background_img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/background/{i}.png".replace("/",slash))
                background_img_scale= pygame.transform.scale(background_img, ((1300/new_pos_x),(700/new_pos_y)))
                screen.blit(background_img_scale, ( 75/new_pos_x ,(85 + int(bg_position_y[i]))/new_pos_x ))

                
                delete_img_scale = pygame.transform.scale(bin_btn_img, ((100/new_pos_x),(100/new_pos_y)))
                delete_img_scale_v2 = pygame.transform.scale(bin_btn_img_v2, ((100/new_pos_x),(100/new_pos_y)))
                delete_img_btn = button.Button(1750 /new_pos_x,(118+(113*i))/new_pos_y,delete_img_scale, 1,True,delete_img_scale_v2)
                delete_btn_list.append(delete_img_btn)

    except:
        pass  

# ---- delete bug file ("1 2.png")
def bug_file_del():
    folder_path = f'{script_path}/GameEngineSave/{user_text}/block'
    for dirpath, _, filenames in os.walk(folder_path):
        for file_name in filenames:
            if " " in file_name:
                file_path = os.path.join(dirpath, file_name)
                os.remove(file_path)

#
#
#

#!=== choose Player type Main Loop ===
#*=== Loop === 
def choose_player_type_screen(back_status = False):
    global  run, screen_width, screen_hight, new_pos_x, new_pos_y, melee_player_img, range_player_img
    while run:
        delete_ds_store(script_path)
        clock.tick(fps)
        player_choose_scale = pygame.transform.scale(player_choose_img, ((1920/new_pos_x),(1080/new_pos_y)))
        screen.blit(player_choose_scale, (0,0))
        # - screen size update -
        scale_pos()
        # --- drawing & function ---
        back_btn_img_scale = pygame.transform.scale(buttons_list[14+button_language], ((400/new_pos_x),(130/new_pos_y)))
        back_btn_img_scale_v2 = pygame.transform.scale(buttons_list[14+button_language], ((400/new_pos_x),(130/new_pos_y)))
        back_btn = button.Button(360/new_pos_x,840/new_pos_y, back_btn_img_scale, 1,True,back_btn_img_scale_v2)

        tutorial_btn_img_scale = pygame.transform.scale(buttons_list[20+button_language], ((400/new_pos_x),(130/new_pos_y)))
        tutorial_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[20+button_language], ((400/new_pos_x),(130/new_pos_y)))
        tutorial_btn = button.Button(1160/new_pos_x,840/new_pos_y, tutorial_btn_img_scale, 1,True,tutorial_btn_img_scale_v2)

        melee_player_scale = pygame.transform.scale(melee_player_img, ((610/new_pos_x),(550/new_pos_y)))
        melee_player_scale_v2 = pygame.transform.scale(melee_player_img_v2, ((610/new_pos_x),(550/new_pos_y)))
        melee_player_btn = button.Button(250/new_pos_x,150/new_pos_y, melee_player_scale, 1,True,melee_player_scale_v2)

        range_player_scale = pygame.transform.scale(range_player_img, ((610/new_pos_x),(550/new_pos_y)))
        range_player_scale_v2 = pygame.transform.scale(range_player_img_v2, ((610/new_pos_x),(550/new_pos_y)))
        range_player_btn = button.Button(1060/new_pos_x,150/new_pos_y, range_player_scale, 1,True,range_player_scale_v2)
        # --- for Event ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                run = False

        # - Button  function -
        if melee_player_btn.draw_button(screen):
            if back_status == True:
                player_file_create("melee")
                import_player_screen("melee",True)
            else:
                player_file_create("melee")
                import_player_screen("melee")
        if range_player_btn.draw_button(screen):
            if back_status == True:
                player_file_create("range")
                import_player_screen("range",True)
            else: 
                player_file_create("range")
                import_player_screen("range")
        
        if back_btn.draw_button(screen):
            if back_status == False:
                import_block_screen()
            else: back_screen()
        if tutorial_btn.draw_button(screen):
            tutorial("player_choose")

        if run: pygame.display.update()

#*=== Funcions === 
# --- create folder ---
def player_file_create(type):
    global number_of_file
    # count variations
    dir_path = f'{script_path}/GameEngineSave/{user_text}/player'.replace("/",slash)
    number_of_file = len(next(os.walk(dir_path))[1])

    if type == "melee":
        number_of_file += 100
    if type == "range":
        number_of_file += 200

    newpath_player_character = f'{script_path}/GameEngineSave/{user_text}/player/{number_of_file}'.replace("/",slash)
    newpath_player_fall = f'{script_path}/GameEngineSave/{user_text}/player/{number_of_file}/fall'.replace("/",slash) 
    newpath_player_idle = f'{script_path}/GameEngineSave/{user_text}/player/{number_of_file}/idle'.replace("/",slash)
    newpath_player_jump = f'{script_path}/GameEngineSave/{user_text}/player/{number_of_file}/jump'.replace("/",slash)
    newpath_player_run = f'{script_path}/GameEngineSave/{user_text}/player/{number_of_file}/run'.replace("/",slash)   
    newpath_player_attack = f'{script_path}/GameEngineSave/{user_text}/player/{number_of_file}/attack'.replace("/",slash) 
    os.makedirs(newpath_player_character)
    os.makedirs(newpath_player_fall)
    os.makedirs(newpath_player_idle)
    os.makedirs(newpath_player_jump)
    os.makedirs(newpath_player_run)
    os.makedirs(newpath_player_attack)
    # copy player assets
    shutil.copytree(f"{script_path}/editor/game_core_image/dust_particles".replace("/",slash), f'{script_path}/GameEngineSave/{user_text}/player/{number_of_file}/dust_particles'.replace("/",slash))

#
#
#

#!=== Inport player Main Loop ===
#*=== Loop === 
def import_player_screen(type , back_status = False):
    global run, screen_width, screen_hight , player_image_path, new_pos_x, new_pos_y, player_img_list
    player_image_status = False
    fall_status, idle_status, run_status, jump_status, attack_status = False, False, False, False, False
    player_import_bg_img_scale = pygame.transform.scale(player_import_bg_img, ((1920/new_pos_x),(1080/new_pos_y)))
    screen.blit(player_import_bg_img_scale, (0/new_pos_x,0/new_pos_y))
    player_img_list = [[],[],[],[],[]]
    player_idle = Player_animate(1,player_img_list)
    player_run = Player_animate(2,player_img_list)
    player_jump = Player_animate(3,player_img_list)
    player_attack = Player_animate(4,player_img_list)
    while run: 
        delete_ds_store(script_path)
        clock.tick(fps)
        # - screen size update -
        scale_pos()
        button_draw_new_poject()
        player_import_bg_img_scale = pygame.transform.scale(player_import_bg_img, ((1920/new_pos_x),(1080/new_pos_y)))
        # --- drawing & function ---
        drag_drop_player_img_scale = pygame.transform.scale(drag_drop_player_img, ((240/new_pos_x),(500/new_pos_y)))
        
        # --- for Event ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                shutil.rmtree(f"{script_path}/GameEngineSave/{user_text}/player/{number_of_file}")
                pygame.quit()
                run = False
            
            x_y_mouse = pygame.mouse.get_pos()
            x_mouse = int(x_y_mouse[0])*new_pos_x
            y_mouse = int(x_y_mouse[1])*new_pos_y
            if 160 <= x_mouse <= 400 and 150 <= y_mouse <= 650:
                if event.type == pygame.DROPFILE:  
                    screen.blit(drag_drop_player_img_scale, (160/new_pos_x, 100/new_pos_y))
                    player_image_path = str(event)
                    import_player_img(type,number_of_file, "fall")
                    load_player_img(number_of_file,0)
                    fall_status = True
            elif 500 <= x_mouse <= 740 and 150 <= y_mouse <= 650: 
                screen.blit(drag_drop_player_img_scale, (500/new_pos_x, 150/new_pos_y)) 
                if event.type == pygame.DROPFILE:
                    player_image_path = str(event)
                    import_player_img(type,number_of_file, "idle")
                    load_player_img(number_of_file,1)
                    idle_status = True
            elif 840 <= x_mouse <= 1080 and 150 <= y_mouse <= 650:  
                screen.blit(drag_drop_player_img_scale, (840/new_pos_x, 150/new_pos_y))
                if event.type == pygame.DROPFILE:
                    player_image_path = str(event)
                    import_player_img(type,number_of_file, "run")
                    load_player_img(number_of_file,2)
                    run_status = True
            elif 1180 <= x_mouse <= 1420 and 150 <= y_mouse <= 650: 
                screen.blit(drag_drop_player_img_scale, (1180/new_pos_x, 150/new_pos_y)) 
                if event.type == pygame.DROPFILE:
                    player_image_path = str(event)
                    import_player_img(type,number_of_file, "jump")
                    load_player_img(number_of_file,3)
                    jump_status = True
            elif 1520 <= x_mouse <= 1760 and 150 <= y_mouse <= 650:
                screen.blit(drag_drop_player_img_scale, (1520/new_pos_x, 150/new_pos_y))  
                if event.type == pygame.DROPFILE:
                    player_image_path = str(event)
                    import_player_img(type,number_of_file, "attack")
                    load_player_img(number_of_file,4)
                    attack_status = True
            else:
                screen.blit(player_import_bg_img_scale, (0/new_pos_x,0/new_pos_y))

        screen.blit(player_import_bg_img_scale, (0/new_pos_x,0/new_pos_y))
        player_idle.run()
        player_run.run()
        player_attack.run()
        player_jump.run()
        draw_player_img()
        # - Button  function -
        if fall_status == True and idle_status == True and run_status == True and jump_status == True and attack_status == True:
            player_image_status = True

        if back_btn.draw_button(screen):
            shutil.rmtree(f"{script_path}/GameEngineSave/{user_text}/player/{number_of_file}".replace("/",slash))
            choose_player_type_screen(back_status)
        if tutorial_btn.draw_button(screen):
            tutorial("player_import")
        if next_btn.draw_button(screen):
            if player_image_status == True:
                if back_status == True: back_screen()
                else:choose_enemy_type_screen()
            else: error("player_import")

        if run: pygame.display.update()

#*=== Funcions === 
def import_player_img(type, player_num,move):
    global player_image_num , player_image_path
    # - count number of file in folder - 
    file_path = f'{script_path}/GameEngineSave/{user_text}/player/{player_num}/{move}'.replace("/",slash)
    player_image_num = 1
    for path in os.listdir(file_path):
        if os.path.isfile(os.path.join(file_path, path)):
            player_image_num += 1
    
    # - copy and paste file -        
    original= r"A"
    
    if move == "fall" and player_image_num == 1:
        player_image = "fall"
    elif move == "idle" and player_image_num <= 5:
        player_image = player_image_num
    elif move == "run" and player_image_num <= 6:
        player_image = player_image_num
    elif move == "jump" and player_image_num <= 3:
        player_image = player_image_num
    elif move == "attack" and player_image_num <= 2:
        player_image = player_image_num
    try:
        target = f"{script_path}/GameEngineSave/{user_text}/player/{player_num}/{move}/{player_image}.png".replace("/",slash)
        original = original.replace("A",(player_image_path[31:-4:]))
        image = pygame.image.load(original)
        image_rect = image.get_bounding_rect()
        crop_rect = pygame.Rect(image_rect.x, image_rect.y, image_rect.width, image_rect.height)
        cropped_image = image.subsurface(crop_rect)
        pygame.image.save(cropped_image, target)
    except:
        pass

def draw_player_img():
    try:
        screen.blit(player_img_list[0][int(0)], (160/new_pos_x, 320/new_pos_y))
    except:pass

def load_player_img(file_number,i):
    global player_img_list 
    idle_path = f'{script_path}/GameEngineSave/{user_text}/player/{file_number}/idle'.replace("/",slash)
    idle_num = len([f for f in os.listdir(idle_path) if os.path.isfile(os.path.join(idle_path, f))])
    run_path = f'{script_path}/GameEngineSave/{user_text}/player/{file_number}/run'.replace("/",slash)
    run_num = len([f for f in os.listdir(run_path) if os.path.isfile(os.path.join(run_path, f))])
    attack_path = f'{script_path}/GameEngineSave/{user_text}/player/{file_number}/attack'.replace("/",slash)
    attack_num = len([f for f in os.listdir(attack_path) if os.path.isfile(os.path.join(attack_path, f))])
    jump_path = f'{script_path}/GameEngineSave/{user_text}/player/{file_number}/jump'.replace("/",slash)
    jump_num = len([f for f in os.listdir(jump_path) if os.path.isfile(os.path.join(jump_path, f))])

    if i == 1:
        for x in range(idle_num):
            img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/player/{file_number}/idle/{x+1}.png".replace("/",slash)).convert_alpha() 
            img_scale = pygame.transform.scale(img, ((240/new_pos_x),(320/new_pos_y)))
            player_img_list[i].append(img_scale)
    elif i == 2:
        for x in range(run_num):
            img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/player/{file_number}/run/{x+1}.png".replace("/",slash)).convert_alpha() 
            img_scale = pygame.transform.scale(img, ((240/new_pos_x),(320/new_pos_y)))
            player_img_list[i].append(img_scale)
    elif i == 3:
        for x in range(jump_num):
            img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/player/{file_number}/jump/{x+1}.png".replace("/",slash)).convert_alpha() 
            img_scale = pygame.transform.scale(img, ((240/new_pos_x),(320/new_pos_y)))
            player_img_list[i].append(img_scale)
    elif i == 4:
        for x in range(attack_num):
            img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/player/{file_number}/attack/{x+1}.png".replace("/",slash)).convert_alpha() 
            img_scale = pygame.transform.scale(img, ((240/new_pos_x),(320/new_pos_y)))
            player_img_list[i].append(img_scale)
    elif i == 0:
        img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/player/{file_number}/fall/fall.png".replace("/",slash)).convert_alpha() 
        img_scale = pygame.transform.scale(img, ((240/new_pos_x),(320/new_pos_y)))
        player_img_list[i].append(img_scale)

class Player_animate:
    def __init__(self,num,player_img_list):
        self.animations_speed = 0.15
        self.img_index = 0
        self.num = num
        self.player_img_list = player_img_list

    def animate(self):
        try:
            screen.blit(self.player_img_list[self.num][int(self.img_index)], (120+(340*self.num)/new_pos_x, 320/new_pos_y))
        except:pass

    def run(self):
        self.img_index += self.animations_speed
    
        if self.img_index > len(self.player_img_list[self.num]):
            self.img_index = 0
        self.animate()
    
#
#
#

#!=== choose enemies type Main Loop ===
#*=== Loop === 
def choose_enemy_type_screen(back_status = False):
    global  run, screen_width, screen_hight, new_pos_x, new_pos_y
    while run:
        delete_ds_store(script_path)
        clock.tick(fps)
        enemy_choose_scale = pygame.transform.scale(player_choose_img, ((1920/new_pos_x),(1080/new_pos_y)))
        screen.blit(enemy_choose_scale, (0,0))
        # - screen size update -
        scale_pos()
        # --- drawing & function ---
        back_btn_img_scale = pygame.transform.scale(buttons_list[14+button_language], ((400/new_pos_x),(130/new_pos_y)))
        back_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[14+button_language], ((400/new_pos_x),(130/new_pos_y)))
        back_btn = button.Button(360/new_pos_x,840/new_pos_y, back_btn_img_scale, 1,True,back_btn_img_scale_v2)

        tutorial_btn_img_scale = pygame.transform.scale(buttons_list[20+button_language], ((400/new_pos_x),(130/new_pos_y)))
        tutorial_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[20+button_language], ((400/new_pos_x),(130/new_pos_y)))
        tutorial_btn = button.Button(1160/new_pos_x,840/new_pos_y, tutorial_btn_img_scale, 1,True,tutorial_btn_img_scale_v2)

        walking_enemy_scale = pygame.transform.scale(walking_enemy_btn_img, ((610/new_pos_x),(550/new_pos_y)))
        walking_enemy_scale_v2 = pygame.transform.scale(walking_enemy_btn_img_v2, ((610/new_pos_x),(550/new_pos_y)))
        walking_enemy_btn = button.Button(250/new_pos_x,150/new_pos_y, walking_enemy_scale, 1,True,walking_enemy_scale_v2)

        standing_range_enemy_scale = pygame.transform.scale(range_enemy_btn_img, ((610/new_pos_x),(550/new_pos_y)))
        standing_range_enemy_scale_v2 = pygame.transform.scale(range_enemy_btn_img_v2, ((610/new_pos_x),(550/new_pos_y)))
        standing_range_enemy_btn = button.Button(1060/new_pos_x,150/new_pos_y, standing_range_enemy_scale, 1,True,standing_range_enemy_scale_v2)
        # --- for Event ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                run = False

        # - Button  function -
        if walking_enemy_btn.draw_button(screen):
            creating_folder_for_enemy(300)
            walking_enemy_import_img(back_status)

        if standing_range_enemy_btn.draw_button(screen):
            creating_folder_for_enemy(400)
            shooting_enemy_import_img(back_status)
        
        if back_btn.draw_button(screen):
            if back_status == False:
                choose_player_type_screen(back_status)
            else: back_screen()
        if tutorial_btn.draw_button(screen):
            tutorial("enemy_choose")

        if run: pygame.display.update()

#*=== Funcions === 
def creating_folder_for_enemy(folder_name):
    global current_enemy
    # - Count Number of File in Folder - 
    path = f'{script_path}/GameEngineSave/{user_text}/enemies'.replace("/",slash)
    number_of_file = len(next(os.walk(path))[1])
    folder_name += number_of_file
    # - Create Folder
    folder_path = f'{script_path}/GameEngineSave/{user_text}/enemies/{folder_name}'.replace("/",slash)
    os.makedirs(folder_path)
    if 300 <= folder_name <=  399:
        walk_folder = f'{script_path}/GameEngineSave/{user_text}/enemies/{folder_name}/walk'.replace("/",slash)
        os.makedirs(walk_folder)
    elif 400 <= folder_name <= 499:
        walk_folder = f'{script_path}/GameEngineSave/{user_text}/enemies/{folder_name}/stand'.replace("/",slash) 
        os.makedirs(walk_folder)
        walk_folder = f'{script_path}/GameEngineSave/{user_text}/enemies/{folder_name}/shoot'.replace("/",slash) 
        os.makedirs(walk_folder)

    current_enemy = folder_name

#
#
#

#!=== Enemy walking ===      
#*=== Loop === 
def walking_enemy_import_img(back_status = False):
    global run, walk_enemy_img_list
    walk_enemy_img_list = [[],"walk"]
    enemy_walk_animate = Enemy_animate(0,walk_enemy_img_list)
    while run:
        delete_ds_store(script_path)
        clock.tick(fps)
        screen.fill("red",(0,0,screen_width,screen_hight))
        # - screen size update -
        scale_pos()
        button_draw_new_poject()
        import_walk_enemy_scale = pygame.transform.scale(import_walk_enemy, ((1920/new_pos_x),(1080/new_pos_y)))
        screen.blit(import_walk_enemy_scale, (0,0))
        # --- drawing & function ---

        # --- for Event ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                shutil.rmtree(f"{script_path}/GameEngineSave/{user_text}/enemies/{current_enemy}".replace("/",slash))
                pygame.quit()
                run = False
            x_y_mouse = pygame.mouse.get_pos()
            x_mouse = int(x_y_mouse[0])*new_pos_x
            y_mouse = int(x_y_mouse[1])*new_pos_y

            if 666 <= x_mouse <= 1266 and 110 <= y_mouse <= 700:
                if event.type == pygame.DROPFILE:  
                    enemy_img_path = str(event)
                    save_enemy_img(f'{script_path}/GameEngineSave/{user_text}/enemies/{current_enemy}/walk'.replace("/",slash),enemy_img_path,"walk")

        if back_btn.draw_button(screen): 
            shutil.rmtree(f"{script_path}/GameEngineSave/{user_text}/enemies/{current_enemy}".replace("/",slash))
            choose_enemy_type_screen(back_status)
        if tutorial_btn.draw_button(screen):
            tutorial("enemy_import")
        directory = f"{script_path}/GameEngineSave/{user_text}/enemies/{current_enemy}/walk".replace("/",slash)
        walk_enemy_files = os.listdir(directory)
        if next_btn.draw_button(screen):
            if len(walk_enemy_files) < 2:
                error("walk_enemy")
            else:
                if back_status == False:
                    level_editor_screen()
                else: back_screen()

        enemy_walk_animate.run()
        if run: pygame.display.update()

#!=== Enemy shooting === 
#*=== Loop === 
def shooting_enemy_import_img(back_status = False):
    global run, shoot_enemy_img_list, reload_enemy_img_list
    shoot_enemy_img_list, reload_enemy_img_list = [[],"shoot"],[[],"idle"]
    enemy_shoot_animate = Enemy_animate(0,shoot_enemy_img_list)
    enemy_reload_animate = Enemy_animate(0,reload_enemy_img_list)
    while run:
        delete_ds_store(script_path)
        clock.tick(fps)
        import_shooting_enemy
        import_shooting_enemy_scale = pygame.transform.scale(import_shooting_enemy, ((1920/new_pos_x),(1080/new_pos_y)))
        screen.blit(import_shooting_enemy_scale, (0,0))
        
        # - screen size update -
        scale_pos()
        button_draw_new_poject()
        # --- drawing & function ---

        # --- for Event ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                shutil.rmtree(f"{script_path}/GameEngineSave/{user_text}/enemies/{current_enemy}".replace("/",slash))
                pygame.quit()
                run = False
            x_y_mouse = pygame.mouse.get_pos()
            x_mouse = int(x_y_mouse[0])*new_pos_x
            y_mouse = int(x_y_mouse[1])*new_pos_y
            if 220 <= x_mouse <= 800 and 120 <= y_mouse <= 700:
                if event.type == pygame.DROPFILE:  
                    enemy_img_path = str(event)
                    save_enemy_img(f'{script_path}/GameEngineSave/{user_text}/enemies/{current_enemy}/shoot'.replace("/",slash),enemy_img_path,"shoot")
            
            if 1120 <= x_mouse <= 1720 and 120 <= y_mouse <= 700:
                if event.type == pygame.DROPFILE:  
                    enemy_img_path = str(event)
                    save_enemy_img(f'{script_path}/GameEngineSave/{user_text}/enemies/{current_enemy}/stand'.replace("/",slash),enemy_img_path,"idle")

        if back_btn.draw_button(screen):
            shutil.rmtree(f"{script_path}/GameEngineSave/{user_text}/enemies/{current_enemy}".replace("/",slash))
            choose_enemy_type_screen(back_status)
        if tutorial_btn.draw_button(screen):
            tutorial("enemy_import")
        directory_stand = f"{script_path}/GameEngineSave/{user_text}/enemies/{current_enemy}/shoot".replace("/",slash)
        stand_enemy_files = os.listdir(directory_stand)
        directory_shoot = f"{script_path}/GameEngineSave/{user_text}/enemies/{current_enemy}/stand".replace("/",slash)
        shoot_enemy_files = os.listdir(directory_shoot)
        if next_btn.draw_button(screen):
            if len(stand_enemy_files) < 2 or len(shoot_enemy_files) < 1 :
                error("walk_enemy")
            else:
                if next_btn.draw_button(screen):
                    if back_status == False:
                        level_editor_screen()
                    else: back_screen()

        enemy_shoot_animate.run()
        enemy_reload_animate.run()
        if run: pygame.display.update()

#*=== Funcions === 
def save_enemy_img(folder_path,img_path,move):
    global walk_enemy_img_list,shoot_enemy_img_list , reload_enemy_img_list
    original= r"A"
    path = folder_path
    number_of_file = len([f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))])
    target = f"{folder_path}/{number_of_file}.png".replace("/",slash)
    original = original.replace("A",(img_path[31:-4:]))
    image = pygame.image.load(original)
    image_rect = image.get_bounding_rect()
    crop_rect = pygame.Rect(image_rect.x, image_rect.y, image_rect.width, image_rect.height)
    cropped_image = image.subsurface(crop_rect)
    if move == "walk":
        walk_enemy_img_list[0].append(cropped_image)
    elif move == "shoot":
        shoot_enemy_img_list[0].append(cropped_image)
    elif move == "idle":
        reload_enemy_img_list[0].append(cropped_image)

    pygame.image.save(cropped_image, target)
   
class Enemy_animate:
    def __init__(self,num,enemy_img_list,):
        self.animations_speed = 0.15
        self.img_index = 0
        self.num = num
        self.enemy_img_list = enemy_img_list
 

    def animate(self):
        try:
            if self.enemy_img_list[1] == "walk":
                self.image = pygame.transform.scale(self.enemy_img_list[self.num][int(self.img_index)], ((460/new_pos_x),(460/new_pos_y)))
                screen.blit(self.image, (736/new_pos_x, 220/new_pos_y))
            elif self.enemy_img_list[1] == "shoot":
                self.image = pygame.transform.scale(self.enemy_img_list[self.num][int(self.img_index)], ((460/new_pos_x),(460/new_pos_y)))
                screen.blit(self.image, (290/new_pos_x, 220/new_pos_y))
            elif self.enemy_img_list[1] == "idle":
                self.image = pygame.transform.scale(self.enemy_img_list[self.num][int(self.img_index)], ((460/new_pos_x),(460/new_pos_y)))
                screen.blit(self.image, (1190/new_pos_x, 220/new_pos_y))
        except:pass

    def run(self):
        self.img_index += self.animations_speed
    
        if self.img_index > len(self.enemy_img_list[self.num]):
            self.img_index = 0
        self.animate()
    
#
#
#

#!=== === Load Project === === 
#*=== Loop ===  
def load_project():
    global run, screen_hight, screen_width, game_save,text_button_list,load_project_bg_img,text_button_img_list,user_text,text_rext_list,text_text,mouse_button_0_down
    while run:
        delete_ds_store(script_path)
        clock.tick(fps)
        # - screen size update -
        scale_pos()
        # --- drawing & function ---
        player_img = pygame.transform.scale(load_project_bg_img,( 1920/new_pos_x, 1080/new_pos_y))
        screen.blit(player_img, (0,0))
        text_button_img_list = []
        game_save_files()

        creating_button()
        back_btn_img_scale = pygame.transform.scale(buttons_list[14+button_language], ((400/new_pos_x),(130/new_pos_y)))
        back_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[14+button_language], ((400/new_pos_x),(130/new_pos_y)))
        back_btn = button.Button(760/new_pos_x,840/new_pos_y, back_btn_img_scale, 1,True,back_btn_img_scale_v2)

        # --- draw text button to screen --- 
        x = -1
        for i in text_button_list:
            x += 1
            if i.draw_button(screen):
                user_text = game_save[x]
                mouse_button_0_down = True
                back_screen()
                

        for i in range(len(text_rext_list)):
            screen.blit(text_text[i], text_rext_list[i])
        # --- for Event ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
        
        if back_btn.draw_button(screen):
            menu_screen()

        project_delete()
        if run: pygame.display.update()

#*=== Funcions === 
# --- load list of all files ---
def game_save_files():
    global game_save
    game_save_path = f"{script_path}/GameEngineSave".replace("/",slash)
    game_save = os.listdir(game_save_path)
    try: game_save.remove(".DS_Store")
    except: pass

# --- creating button ---
def creating_button():
    global text_button_list, text_rect, text,text_rext_list,text_text,load_project_page
    left_arrow_img_scale = pygame.transform.scale(left_arrow_btn_img, ((80/new_pos_x),(80/new_pos_y)))
    left_arrow_img_scale_v2 = pygame.transform.scale(left_arrow_btn_img_v2, ((80/new_pos_x),(80/new_pos_y)))
    left_arrow_btn = button.Button(830/new_pos_x,640/new_pos_y, left_arrow_img_scale, 1,True,left_arrow_img_scale_v2)
    right_arrow_img_scale = pygame.transform.scale(right_arrow_btn_img, ((80/new_pos_x),(80/new_pos_y)))
    right_arrow_img_scale_v2 = pygame.transform.scale(right_arrow_btn_img_v2, ((80/new_pos_x),(80/new_pos_y)))
    right_arrow_btn = button.Button(1010/new_pos_x,640/new_pos_y, right_arrow_img_scale, 1,True,right_arrow_img_scale_v2)
    text_button_col = 0
    text_button_row = 0
    text_button_list = []
    text_text = []
    text_rext_list = []
    for i in range(len(game_save)):
        folder_ikon_btn_scale = pygame.transform.scale(folder_ikon_btn, ((350/new_pos_x),(150/new_pos_y)))
        folder_ikon_btn_v2_scale = pygame.transform.scale(folder_ikon_btn_v2, ((350/new_pos_x),(150/new_pos_y)))
        if -6 <= i-6*load_project_page < 0:
            text_button = button.Button((333 + (450* text_button_col))/new_pos_x, (150 + (250 * text_button_row))/new_pos_y, folder_ikon_btn_scale, 1, True, folder_ikon_btn_v2_scale )
            text_button_list.append(text_button) 

            base_font = pygame.font.Font(my_font,int(62/new_pos_x))
            text = base_font.render(game_save[i], True, (0, 255, 0))
            text_rect = text.get_rect()
            text_rect.center = (((335 + (450* text_button_col))+175)/new_pos_x, ((150 + (250 * text_button_row))+75)/new_pos_y)
            text_rext_list.append(text_rect)
            text_text.append(text)
            text_button_col += 1
        if text_button_col == 3: 
            text_button_col = 0
            text_button_row += 1

    if left_arrow_btn.draw_button(screen) and load_project_page > 1 :
        load_project_page -= 1   
        text_button_col = 0
        text_button_row = 0
    if right_arrow_btn.draw_button(screen) and load_project_page*6 < len(game_save):
        load_project_page += 1 
        text_button_col = 0
        text_button_row = 0           

# === Load project Main loop ===
def project_delete():
    global file_name
    text_button_col = 0
    text_button_row = 0
    delete_project_button_list = []
    path = f"{script_path}/GameEngineSave".replace("/",slash)
    project_name = [f for f in os.listdir(path) if os.path.isdir(os.path.join(path, f))]
    
    for i in range(len(project_name)):
        if -6 <= i-6*load_project_page < 0:
            delete_img_scale = pygame.transform.scale(bin_btn_img, ((40/new_pos_x),(40/new_pos_y)))
            delete_img_scale_v2 = pygame.transform.scale(bin_btn_img_v2, ((40/new_pos_x),(40/new_pos_y)))
            delete_img_btn = button.Button(((335 + (450* text_button_col))+310)/new_pos_x, ((150 + (250 * text_button_row))+0)/new_pos_y,delete_img_scale,1,True,delete_img_scale_v2)
            delete_project_button_list.append(delete_img_btn)

            text_button_col += 1
        if text_button_col == 3: 
            text_button_col = 0
            text_button_row += 1
        
    for position,i in enumerate(delete_project_button_list):
        if i.draw_button(screen):
            file_name = str(project_name[position+(6*load_project_page-6)])
            folder_delete_confirmations()

# == Delete confimations == 
def folder_delete_confirmations():
    global run 
    class_folder = FolderDeleteConfirmations()
    while run:
        clock.tick(fps)
        scale_pos()
        class_folder.run()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                pygame.quit()
                
        folder_delete_confimations_bg_scale = pygame.transform.scale(folder_delete_confimations_bg, ((1000/new_pos_x),(640/new_pos_y)))
        screen.blit(folder_delete_confimations_bg_scale, (460/new_pos_y,170/new_pos_y))
        screen.blit(folder_delete_text, (960/new_pos_x-370/new_pos_x, 490/new_pos_y))

        if no_btn.draw_button(screen):
            load_project()
        
        if yes_btn.draw_button(screen):
            shutil.rmtree(f"{script_path}/GameEngineSave/{file_name}".replace("/",slash))
            load_project()

        if run: pygame.display.update()

class FolderDeleteConfirmations:
    def button_placing(self):
        global no_btn, yes_btn
        no_img_scale = pygame.transform.scale(buttons_list[33+button_language], ((200/new_pos_x),(100/new_pos_y)))
        no_img_v2_scale = pygame.transform.scale(buttons_list_v2[33+button_language], ((200/new_pos_x),(100/new_pos_y)))
        no_btn = button.Button(660/new_pos_x,600/new_pos_y, no_img_scale, 1, True, no_img_v2_scale)
        yes_img_scale = pygame.transform.scale(buttons_list[29+button_language], ((200/new_pos_x),(100/new_pos_y)))
        yes_img_v2_scale = pygame.transform.scale(buttons_list_v2[29+button_language], ((200/new_pos_x),(100/new_pos_y)))
        yes_btn = button.Button(1060/new_pos_x,600/new_pos_y, yes_img_scale, 1, True, yes_img_v2_scale)

    def text_placing(self):
        global folder_delete_text
        self.font = pygame.font.Font(my_font, int(32/new_pos_x))
        folder_delete_text = self.font.render(f"Do you really want to delete file: {file_name}?", True, (0, 0, 0))

    def run(self):
        self.button_placing()
        self.text_placing()

#
#
#
#
#
#
#

#!=== === Back Screen === === 
#*=== Loop ===  
def back_screen():
    global run, mouse_button_0_down
    back_class = BackScreen()
    while run:
        delete_ds_store(script_path)
        clock.tick(fps)
        back_img_bg_scale = pygame.transform.scale(back_img_bg, ((1920/new_pos_x),(1080/new_pos_y)))
        screen.blit(back_img_bg_scale,(0/new_pos_x,0/new_pos_y))
        back_class.run()
        # - screen size update -
        scale_pos()
        # --- for Event ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                run = False

        # -- Button -- 
        if screen_btn[0].draw_button(screen):
            import_finish_line_screen(True)
        if screen_btn[1].draw_button(screen):
            new_project_screen_import_bg(True)
        if screen_btn[2].draw_button(screen):
            import_block_screen(True)
        if screen_btn[3].draw_button(screen):
            choose_player_type_screen(True)
        if screen_btn[4].draw_button(screen):
            choose_enemy_type_screen(True)
        if screen_btn[5].draw_button(screen):
            mouse_button_0_down = True
            try:level_editor_screen()
            except:error("error")
       
        if back_btn.draw_button(screen):
            load_project()
        
        if tutorial_btn.draw_button(screen):
            tutorial("back")

        if run: pygame.display.update()

#*=== Funcions === 
class BackScreen:
    def __init__(self):
        self.screen_img = []
        self.load_img()

    def button_placing(self):
        global screen_btn,back_btn, tutorial_btn
        
        # make list of screen buttons
        screen_btn, self.row, self.collum  = [], 0, 0
        for i in range(0,11,2):
            self.row += 1
            self.btn_1 = pygame.transform.scale(self.screen_img[i], ((200/new_pos_x),(200/new_pos_y)))
            self.btn_2 =  pygame.transform.scale(self.screen_img[i+1], ((200/new_pos_x),(200/new_pos_y)))
            self.screen_btn = button.Button((250+(300*self.row))/new_pos_x,(105+(300*self.collum))/new_pos_y, self.btn_1, 1, True, self.btn_2 )
            screen_btn.append(self.screen_btn)
           
            if i == 4:
                self.row = 0
                self.collum += 1
        
        # make list of rest buttons
        back_btn_img_scale = pygame.transform.scale(buttons_list[14+button_language], ((400/new_pos_x),(130/new_pos_y)))
        back_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[14+button_language], ((400/new_pos_x),(130/new_pos_y)))
        back_btn = button.Button(460/new_pos_x,840/new_pos_y, back_btn_img_scale, 1,True,back_btn_img_scale_v2)
        
        tutorial_btn_img_scale = pygame.transform.scale(buttons_list[20+button_language], ((400/new_pos_x),(130/new_pos_y)))
        tutorial_btn_img_v2_scale = pygame.transform.scale(buttons_list_v2[20+button_language], ((400/new_pos_x),(130/new_pos_y)))
        tutorial_btn = button.Button(1060/new_pos_x,840/new_pos_y, tutorial_btn_img_scale, 1, True, tutorial_btn_img_v2_scale)


    def load_img(self):
        # load Button
        for i in range(12):
            self.img = pygame.image.load(f"{script_path}/image/Button/back_screen/{i}.png".replace("/",slash)).convert_alpha()
            self.screen_img.append(self.img)

    def run(self):
        self.button_placing()

#
#
#

#+=== === Editor (2. STEP) === ===
#!=== === Level Editor === ===
#*=== Loop ===  
def level_editor_screen():
    global run, screen_width, screen_hight,finnish_list,finnish_load_time,block_list,player_list,background_img_list,player_load_time,bloack_load_time,load_bacground, scroll, scroll_left, scroll_right, scroll_speed, current_block, world_data, mouse_button_0_down
    delete_ds_store(script_path)
    # -- create world list --
    for row in range(row_tile):
        r = [-1] * (col_tile * screen_reapeat)
        world_data.append(r)
    for tile in range(0, (col_tile*screen_reapeat)):
        world_data[row_tile - 1][tile] = 0
    load_bacground,bloack_load_time,player_load_time,finnish_load_time= 0,0,0,0
    finnish_list,block_list,player_list,background_img_list = [],[],[],[]
    load()
    while run:
        clock.tick(fps)
        # - screen size update -
        screen_width, screen_hight = screen.get_size()
        new_pos_x = (original_screen_width/screen_width)
        new_pos_y = (original_screen_hight/screen_hight)
        # --- drawing & function ---
        screen.fill("blue")
        draw_bg()
        draw_tile()   
        draw_world()
        draw_UI()

        # - scrolling - 
        if scroll < 0:
            scroll -= scroll

        if scroll_left == True and scroll > 0:
            scroll -=15 / new_pos_x * scroll_speed
        if scroll_right == True and scroll < col_tile*screen_reapeat*(tile_size/new_pos_x)-1300: 
            scroll +=15 /new_pos_x * scroll_speed
            
         # --- add new tiles to world ---
        pos =  pygame.mouse.get_pos()
        x = (pos[0] + scroll) // (tile_size/ new_pos_x)
        y = pos[1]// (tile_size/ new_pos_y)

        # - check if mouse is in area -
        if pos[0] < (1300/new_pos_y) and pos[1] < (700/new_pos_y) and not mouse_button_0_down:
            if pygame.mouse.get_pressed()[0] == 1:
                if world_data[int(y)][int(x)] != current_block:
                    world_data[int(y)][int(x)] = current_block
            if pygame.mouse.get_pressed()[2] == 1:
                 world_data[int(y)][int(x)] = -1

        # --- for Event ---
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                run = False
            if event.type == pygame.MOUSEBUTTONUP:
                mouse_button_0_down = False
                
            # - keys detect -
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    scroll_left = True 
                if event.key == pygame.K_d:
                    scroll_right = True
                if event.key == pygame.K_LSHIFT:
                    scroll_speed = 4
                    
            # - detect if key is release -
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    scroll_left = False 
                if event.key == pygame.K_d:
                    scroll_right = False  
                if event.key == pygame.K_LSHIFT:
                    scroll_speed = 1

        if run: pygame.display.update()

#*=== Funcions === 
# --- function for drawing world ---
def draw_world():
    global world_data, block_img_list ,current_block
    scale_pos()
    for y, row in enumerate(world_data):
        for x, tile in enumerate(row):  
            tile = int(tile)
            if 99 >= tile >= 0:
                screen.blit(block_img_list[tile], (x * (tile_size/new_pos_x)-scroll, y  * tile_size/new_pos_y))
            elif 100 <= tile <=299:
                num = tile
       
                if tile <= 199:
                    num -= 100
                elif 199 < tile <= 299:
                    num -= 200 
                player_img = pygame.transform.scale(player_img_tile[num], ((46.6666/new_pos_x),(46.6666/new_pos_y)))
                screen.blit(player_img, (x * (tile_size/new_pos_x)-scroll, y  * tile_size/new_pos_y))
            elif 300 <= tile <= 499:
                num = tile
                if 300 <= tile <=  399:
                    num -= 300
                elif 400 <= tile <= 499:
                    num -= 400
                enemy_img = pygame.transform.scale(enemy_img_tile[num], ((46.6666/new_pos_x),(46.6666/new_pos_y)))
                screen.blit(enemy_img, (x * (tile_size/new_pos_x)-scroll, y  * tile_size/new_pos_y))
            elif -100 >= tile >= -199:
                num = (tile + 100)*-1
                finnish_img = pygame.transform.scale(finnish_img_tile[0], ((46.6666/new_pos_x),(46.6666/new_pos_y)))
                screen.blit(finnish_img, (x * (tile_size/new_pos_x)-scroll, y  * tile_size/new_pos_y))
            elif -200 >= tile >= -299:
                num = (tile + 100)*-1
                coin_img = pygame.transform.scale(finnish_img_tile[1], ((46.6666/new_pos_x),(46.6666/new_pos_y)))
                screen.blit(coin_img, (x * (tile_size)/new_pos_x-scroll, y  * (tile_size)/new_pos_y))

# - Function for drawing BG - 
def draw_bg():
    global level_editor_bg_img, level_building_img,load_bacground,background_img_list,BG_pos_y
    scale_pos()
    # - landscape drawing -
    # count variations
    dir_path = f'{script_path}/GameEngineSave/{user_text}/background'.replace("/",slash)
    count = 0
    for path in os.listdir(dir_path):
        if os.path.isfile(os.path.join(dir_path, path)):
            count += 1
    # loading bg
    
    i = -1
   
    for i in range(count):
        if load_bacground == 0:
                
                with open(f"{script_path}/GameEngineSave/{user_text}/files/back_ground_pos.txt".replace("/",slash)) as f:
                    BG_pos_y = [line.rstrip() for line in f]
          
                background_img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/background/{i}.png".replace("/",slash))
                background_img_list.append(background_img)
        for x in range(screen_reapeat):        
            background_img_scale= pygame.transform.scale(background_img_list[i], ((1300/new_pos_x),(700/new_pos_y)))
            screen.blit(background_img_scale, ((x * background_img_scale.get_width() -scroll),0/new_pos_y+int(BG_pos_y[i])))
    load_bacground = 1

# - Draw tiles - 
def draw_tile():
    draw_UI()
    global tile_size, col_tile
    scale_pos()
    tile_size_x = (original_tile_size / new_pos_y)
    # row line
    for i in range(row_tile+1):
        pygame.draw.line(screen, "black",(0,i*tile_size_x), (screen_width*screen_reapeat,i*tile_size_x))
    # collum line
    collum_y = 700/new_pos_y
    tile_size_y = (original_tile_size / new_pos_x)
    for i in range((col_tile* screen_reapeat)):
        pygame.draw.line(screen, "black",(i*tile_size_y-scroll,0), (i*tile_size_y-scroll,collum_y))

# - draw UI - 
def draw_UI():
    global block_page,player_num,block_list,player_load_time,bloack_load_time,finnish_img_tile,enemy_num,finnish_num,level_num,enemy_img_tile,world_data,rect,player_img_tile,level_editor_bg_img,user_text, block_editor_bg_img, left_arrow_btn_img, right_arrow_btn_img, current_block, block_img_list, back_btn_img ,load_btn_img, save_btn_img
    scale_pos()
    # --- draw BG UI ---
    level_editor_bg_img_scale = pygame.transform.scale(level_editor_bg_img, ((1920/new_pos_x),(1080/new_pos_y)))
    screen.blit(level_editor_bg_img_scale, (0/new_pos_x,0/new_pos_y))
   
    # - Button Draw -
    left_arrow_btn_img_scale = pygame.transform.scale(left_arrow_btn_img, ((80/new_pos_x),(80/new_pos_y)))
    left_arrow_btn_img_scale_v2 = pygame.transform.scale(left_arrow_btn_img_v2, ((80/new_pos_x),(80/new_pos_y)))
    left_arrow_btn = button.Button(1485/new_pos_x,640/new_pos_y, left_arrow_btn_img_scale, 1,True,left_arrow_btn_img_scale_v2)

    right_arrow_btn_img_scale = pygame.transform.scale(right_arrow_btn_img, ((80/new_pos_x),(80/new_pos_y)))
    right_arrow_btn_img_scale_v2 = pygame.transform.scale(right_arrow_btn_img_v2, ((80/new_pos_x),(80/new_pos_y)))
    right_arrow_btn = button.Button(1655/new_pos_x,640/new_pos_y, right_arrow_btn_img_scale, 1,True,right_arrow_btn_img_scale_v2)

    # Save load back
    help_btn_img_scale = pygame.transform.scale(buttons_list[20+button_language], ((170/new_pos_x),(64/new_pos_y)))
    help_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[20+button_language], ((170/new_pos_x),(64/new_pos_y)))
    help_btn = button.Button(1524/new_pos_x,850/new_pos_y, help_btn_img_scale, 1,True,help_btn_img_scale_v2)

    load_btn_img_scale = pygame.transform.scale(buttons_list[38+button_language], ((170/new_pos_x),(64/new_pos_y)))
    load_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[38+button_language], ((170/new_pos_x),(64/new_pos_y)))
    load_btn = button.Button(1426/new_pos_x,760/new_pos_y, load_btn_img_scale, 1,True,load_btn_img_scale_v2)

    save_btn_img_scale = pygame.transform.scale(buttons_list[8+button_language], ((170/new_pos_x),(64/new_pos_y)))
    save_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[8+button_language], ((170/new_pos_x),(64/new_pos_y)))
    save_btn = button.Button(1623/new_pos_x,760/new_pos_y, save_btn_img_scale, 1,True,save_btn_img_scale_v2)

    back_btn_img_scale = pygame.transform.scale(buttons_list[14+button_language], ((170/new_pos_x),(64/new_pos_y)))
    back_btn_img_scale_v2 = pygame.transform.scale(buttons_list_v2[14+button_language], ((170/new_pos_x),(64/new_pos_y)))
    back_btn = button.Button(1524/new_pos_x,971/new_pos_y, back_btn_img_scale, 1,True,back_btn_img_scale_v2)

    right_arrow_btn_img_scale = pygame.transform.scale(right_arrow_btn_img, ((80/new_pos_x),(80/new_pos_y)))
    right_arrow_btn_img_scale_v2 = pygame.transform.scale(right_arrow_btn_img_v2, ((80/new_pos_x),(80/new_pos_y)))
    left_arrow_btn_img_scale = pygame.transform.scale(left_arrow_btn_img, ((80/new_pos_x),(80/new_pos_y)))
    left_arrow_btn_img_scale_v2 = pygame.transform.scale(left_arrow_btn_img_v2, ((80/new_pos_x),(80/new_pos_y)))
    # Player
    left_arrow_player_btn = button.Button(740 /new_pos_x,965/new_pos_y, left_arrow_btn_img_scale, 1,True,left_arrow_btn_img_scale_v2)
    right_arrow_player_btn = button.Button(845/new_pos_x,965/new_pos_y, right_arrow_btn_img_scale, 1,True,right_arrow_btn_img_scale_v2)

    # Enemy
    left_arrow_enemy_btn = button.Button(1040 /new_pos_x,965/new_pos_y, left_arrow_btn_img_scale, 1,True,left_arrow_btn_img_scale_v2)
    right_arrow_enemy_btn = button.Button(1145/new_pos_x,965/new_pos_y,  right_arrow_btn_img_scale, 1,True,right_arrow_btn_img_scale_v2)

    # Finnish    
    left_arrow_finnish_btn = button.Button(440 /new_pos_x,965/new_pos_y, left_arrow_btn_img_scale, 1,True,left_arrow_btn_img_scale_v2)
    right_arrow_finnish_btn = button.Button(545/new_pos_x,965/new_pos_y,  right_arrow_btn_img_scale, 1,True,right_arrow_btn_img_scale_v2)
    
    # level
    left_arrow_level_btn = button.Button(75 /new_pos_x,910/new_pos_y, left_arrow_btn_img_scale, 1,True,left_arrow_btn_img_scale_v2)
    right_arrow_level_btn = button.Button(245/new_pos_x,910/new_pos_y,  right_arrow_btn_img_scale, 1,True,right_arrow_btn_img_scale_v2)
    # - block drawing -
    # count block
    dir_path = f'{script_path}/GameEngineSave/{user_text}/block'.replace("/",slash)
    count = 0
    for path in os.listdir(dir_path):
        if os.path.isfile(os.path.join(dir_path, path)):
            count += 1
    # loading blocks
    block_img_list = []
    
    for i in range(count):

        if bloack_load_time == 0:
            block_img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/block/{i}.png".replace("/",slash))
            block_list.append(block_img)
        block_img_scale = pygame.transform.scale(block_list[i], (((tile_size)/new_pos_x),(tile_size/new_pos_y)))
        block_img_list.append(block_img_scale)
    bloack_load_time = 1

    block_button_list = []
    block_button_col = 0
    block_button_row = 0
    if len(block_img_list)-block_page <= 6:
        block_num = len(block_img_list)-block_page
    else:
        block_num = 6

    for i in range(block_num):
        tile_button =  button.Button((1475 + (170 * block_button_col))/new_pos_x, (150 + (150 * block_button_row))/new_pos_y,block_img_list[i+block_page], 1.438)
        block_button_list.append(tile_button)
        block_button_col += 1
        if block_button_col == 2:
            block_button_col = 0
            block_button_row += 1

    

    # - player button - 
    # creating list of player
    dir_path_player = f'{script_path}/GameEngineSave/{user_text}/player'.replace("/",slash)
    player_file = os.listdir(dir_path_player)
    player_file = sorted(player_file, key=lambda x: int(x[-1]) if x[-1].isdigit() else ord(x[-1]))

    try: player_file.remove(".DS_Store")
    except: pass

    # loading players buttons
    player_btn_list = []
    player_img_tile = []
    for i in range(len(player_file)):
        if player_load_time == 0:
            player_img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/player/{player_file[i]}/idle/1.png".replace("/",slash))
            player_list.append(player_img)
        player_img_scale = pygame.transform.scale(player_list[i], ((200/new_pos_x),(200/new_pos_y)))
        player_img_tile.append(player_img_scale)
        player_btn = button.Button(730/new_pos_x,730/new_pos_y, player_img_scale, 1)
        player_btn_list.append(player_btn)

    player_load_time = 1


    # make list of all enemies 
    enemies_folder_path = f"{script_path}/GameEngineSave/{user_text}/enemies".replace("/",slash)        
    enemies_folder_list = []
    for item in os.listdir(enemies_folder_path):
        if os.path.isdir(os.path.join(enemies_folder_path, item)):
            enemies_folder_list.append(item)
          
    # loading enemies buttons
    enemy_btn_list = []
    enemy_img_tile = []
    for i in range(len(enemies_folder_list)):
        if 300 <= int(enemies_folder_list[i] )<=  399:
            enemy_img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/enemies/{enemies_folder_list[i]}/walk/1.png".replace("/",slash))
        elif 400 <= int(enemies_folder_list[i]) <= 499:
            enemy_img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/enemies/{enemies_folder_list[i]}/stand/1.png".replace("/",slash))
        enemy_img_scale = pygame.transform.scale(enemy_img, ((200/new_pos_x),(200/new_pos_y)))
        enemy_img_tile.append(enemy_img_scale)
        enemy_btn = button.Button(1030/new_pos_x,730/new_pos_y, enemy_img_scale, 1)
        enemy_btn_list.append(enemy_btn)


    # make list of all finnish lines
    finnish_folder_path = f"{script_path}/GameEngineSave/{user_text}/finnish".replace("/",slash)   
    coin_folder_path = f"{script_path}/GameEngineSave/{user_text}/coin".replace("/",slash)
    finnish_folder_list = []
    for item in os.listdir(finnish_folder_path):
        if os.path.isdir(os.path.join(finnish_folder_path, item)):
            finnish_folder_list.append(item)
    for item in os.listdir(coin_folder_path):
        if os.path.isdir(os.path.join(coin_folder_path, item)):
            finnish_folder_list.append(item)
            
    # loading finnish line buttons
    finnish_btn_list = []
    finnish_img_tile = []
    for i in range(len(finnish_folder_list)):
        if finnish_load_time == 0:
            if len(finnish_list) == 0:
                finnish_img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/finnish/-100/0.png".replace("/",slash))
            else: 
                finnish_img = pygame.image.load(f"{script_path}/GameEngineSave/{user_text}/coin/-200/0.png".replace("/",slash))
                
            finnish_list.append(finnish_img)

        finnish_img_scale = pygame.transform.scale(finnish_list[i], ((200/new_pos_x),(200/new_pos_y)))
        finnish_img_tile.append(finnish_img_scale)
        finnish_btn = button.Button(430/new_pos_x,730/new_pos_y, finnish_img_scale, 1)
        finnish_btn_list.append(finnish_btn)

    # tiles selection
    for button_count,i in enumerate(block_button_list):
        # blit block
        if i.draw_button(screen):
            current_block = button_count+block_page
            rect = "tile"
        if rect == "tile":
            try: pygame.draw.rect(screen, "red", block_button_list[current_block-block_page].rect, 3)
            except: pass
        # blit player button
        try:
            if player_btn_list[player_num].draw_button(screen):
                current_block = player_file[player_num]
                rect = "player"
            if rect == "player":
                try: pygame.draw.rect(screen, "red", pygame.Rect(730/new_pos_x,730/new_pos_y,200/new_pos_x,200/new_pos_y) ,3)
                except: pass
        except:
            pass
        try:
            if enemy_btn_list[enemy_num].draw_button(screen):
                    current_block = enemies_folder_list[enemy_num]
                    rect = "enemy"
        except:pass
        if rect == "enemy":
            try: pygame.draw.rect(screen, "red", pygame.Rect(1030/new_pos_x,730/new_pos_y,200/new_pos_x,200/new_pos_y) ,3)
            except: pass
        
        
        if finnish_btn_list[finnish_num].draw_button(screen):
                current_block = finnish_folder_list[finnish_num]
                rect = "finnish"
        if rect == "finnish":
            try: pygame.draw.rect(screen, "red", pygame.Rect(430/new_pos_x,730/new_pos_y,200/new_pos_x,200/new_pos_y) ,3)
            except: pass
    
    # - Button  function -
    if block_page != 0:
        if left_arrow_btn.draw_button(screen):
            block_page -= 6

    if block_page/6+1 <= len(block_img_list)/6:
        if right_arrow_btn.draw_button(screen):
            block_page += 6
    
    # Player btn
    if left_arrow_player_btn.draw_button(screen) and player_num > 0:
        player_num -=1

    if right_arrow_player_btn.draw_button(screen) and player_num < len(player_btn_list)-1:
        player_num += 1
    

    # enemy btn
    if left_arrow_enemy_btn.draw_button(screen) and enemy_num > 0:
        enemy_num -=1
    if right_arrow_enemy_btn.draw_button(screen) and enemy_num < len(enemy_btn_list)-1:
        enemy_num += 1
    
    # finnish btn
    if left_arrow_finnish_btn.draw_button(screen) and finnish_num > 0:
        finnish_num -=1
    if right_arrow_finnish_btn.draw_button(screen) and finnish_num < len(finnish_btn_list)-1:
        finnish_num += 1

    # Level Number
    if left_arrow_level_btn.draw_button(screen) and not level_num == 1:
        save()
        level_num -= 1
        load()

    if right_arrow_level_btn.draw_button(screen):
        save()
        level_num += 1
        level_file = f"{script_path}/GameEngineSave/{user_text}/files/level/{level_num}/data.csv".replace("/",slash)
        if not os.path.exists(level_file):
            newpath = f'{script_path}/GameEngineSave/{user_text}/files/level/{level_num}' .replace("/",slash)
            os.makedirs(newpath)
            world_data = []
            for row in range(row_tile):
                r = [-1] * (col_tile * screen_reapeat)
                world_data.append(r)
            for tile in range(0, (col_tile*screen_reapeat)):
                world_data[row_tile - 1][tile] = 0
            save()

        if os.path.exists(level_file):
            pass

        load()

    # LEvel text
    font = pygame.font.Font(my_font, int(70/new_pos_x))
    text = font.render(f"Level: {level_num}", True, (255, 255, 255))
    text_rect = text.get_rect()
    text_rect.center = (200/new_pos_x,800/new_pos_y)
    screen.blit(text, text_rect)


    # load save back
    if load_btn.draw_button(screen):
        load()
    if save_btn.draw_button(screen):
        save()
    if back_btn.draw_button(screen):
        back_screen()
    if help_btn.draw_button(screen):
        tutorial("editor")
    
# --- Save level ---
def save():
    global world_data
     # save it
    with open(f"{script_path}/GameEngineSave/{user_text}/files/level/{level_num}/data.csv".replace("/",slash), "w", newline="") as csvfile:
        writer = csv.writer(csvfile, delimiter=",")
        for row in world_data:
            writer.writerow(row)

# --- load level ---
def load():
    global scroll, world_data
    # load it
    scroll = 0
    with open(f"{script_path}/GameEngineSave/{user_text}/files/level/{level_num}/data.csv".replace("/",slash), newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter = ',')
        for x, row in enumerate(reader):
        	for y, tile in enumerate(row): 
                    try:
                        world_data[x][y] = int(tile)
                    except:
                        pass



delete_ds_store(script_path)
menu_screen()