import pygame
click = False
class Button:

    def __init__(self, x,y, image, scale,animation = False, img_2 = 0):
        width = image.get_width()
        height = image.get_height()  
        self.image = pygame.transform.scale(image,(int(width*scale), int(height*scale)))
        self.rect = self.image.get_rect()
        self.rect.topleft = (x,y)

        # animations
        try:
            self.img_2 = pygame.transform.scale(img_2,(int(width*scale), int(height*scale)))
        except:
            pass
        self.animation = animation 
        self.ani = False
            
        

    def draw_button(self, surface):
        global click
        try:
            action = False
            pos = (-1,-1)
            pos = pygame.mouse.get_pos()
            if self.rect.collidepoint(pos):
                if pygame.mouse.get_pressed()[0] == 1 and click == False:
                    click = True
                    action = True   
                if self.animation:
                    self.ani = True
                    surface.blit(self.img_2, (self.rect.x, self.rect.y),)

            if pygame.mouse.get_pressed()[0] == False:
                click = False
            
            if self.ani == False:
                surface.blit(self.image, (self.rect.x, self.rect.y))
        
            return action
        except:
            pass
    
    def draw_button_v2(self, surface):
        global click
        try:
            action = False
            pos = (-1,-1)
            pos = pygame.mouse.get_pos()
            if self.rect.collidepoint(pos):
                if pygame.mouse.get_pressed()[0] == 1 and click == False:
                    action = True   

            if pygame.mouse.get_pressed()[0] == False:
                click = False
                
            surface.blit(self.image, (self.rect.x, self.rect.y))
        
            return action
        except:
            pass
    